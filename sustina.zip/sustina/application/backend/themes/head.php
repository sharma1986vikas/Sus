<?php
DEFINE("BASEURL",base_url());
?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>lib/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>jquery.validate.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>stylesheets/theme.css">
<link rel="stylesheet" href="<?php echo base_url();?>lib/font-awesome/css/font-awesome.css">
<script src="<?php echo base_url();?>lib/jquery-1.7.2.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>js/jsFunctions.js" type="text/javascript"></script>
<script>
var BASEURL = '<?php echo base_url();?>';
</script>
<script type="text/javascript" src="<?php echo base_url();?>fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>fancybox/jquery.fancybox-1.3.4.css" media="screen" />

<!--products validations starts-->
<!--<link href="<?php //echo base_url();?>css/jquery.validate.css" rel="stylesheet" type="text/css" />
<script src="<?php //echo base_url();?>js/jquery.validate.js"></script>
--><!--products validations ends-->

<script type="text/javascript">
$(function(){
    $(".fancybox").fancybox({
        type        : 'iframe',
        autoSize : false,
        width    : "70%",
        height   : "70%",
        'scrolling'     : 'no',
        'titleShow'     : false,
        openEffect  : 'fade',
        closeEffect : 'fade',
		'hideOnOverlayClick' : false
    });
});
</script>

<!-- Demo page code -->

<style type="text/css">
#line-chart {
	height: 300px;
	width: 800px;
	margin: 0px auto;
	margin-top: 1em;
}
.brand {
	font-family: georgia, serif;
}
.brand .first {
	color: #ccc;
	font-style: italic;
}
.brand .second {
	color: #fff;
	font-weight: bold;
}
</style>
<style type="text/css">
.clear {
	clear: both;
}
.input_text {
	border: 1px solid red;
}
.mukesh_outer_container {
	width: 50%;
	border: 0px solid green;
	height: auto;
	float: left;
	background-color: transparent;
	border: 1px solid #CECECE;
	margin: 0px 0px 15px 0px;
}
.mukesh_outer_div1 {
	float: left;
	width: 600px;
	border: 0px solid red;
	height: auto;
	padding: 20px 0px 20px 0px;
}
.mukesh_outer_div {
	float: left;
	width: 600px;
	border: 0px solid red;
	height: auto;
}
.mukesh_left_div {
	width: 100px;
	border: 0px solid red;
	float: left;
	padding: 10px 0px 10px 10px;
}
.mukesh_right_div {
	width: 350px;
	border: 0px solid black;
	float: right;
	margin-right: 120px;
}
.mukesh_txt_clone {
	float: right;
}
.mukesh_upload_container {
	width: 80%;
	border: 1px solid green;
	height: auto;
	float: left;
	background-color: transparent;
	border: 1px solid #CECECE;
	margin: 0px 0px 15px 0px;
}
.mukesh_outer_upload {
	float: left;
	width: 700px;
	border: 0px solid red;
	height: 250px;
	margin: 24px 0px 0px 25px;
}
.images_speak {
	color: #C2C4D8;
	font-size: 13px;
	padding: 20px 0px
}
.list_sprt {
	margin-left: 28px;
	list-style-type: none;
}
.list_sprt li {
	border: 1px solid #d9d9d9;
	width: 97px;
	height: 95px;
	background-color: #f5f5f5;
	float: left;
	margin: 0px 15px 30px 0px;
	padding-left: 14px;
	/*border: 1px solid #d9d9d9;
	width: 120px;
	height: 95px;
	background-color: #f5f5f5;
	float: left;
	margin:0px 15px 30px 15px;*/
}
.list_sprt li a {
	color: #515666;
	text-decoration: underline;
	font-size: 13px;
	margin-top: 10px;
}
.list_sprt1 {
	list-style-type: none;
	margin-left: 28px;
}
.list_sprt1 li {
	border: 1px solid #d9d9d9;
	width: 50px;
	height: 61px;
	background-color: #f5f5f5;
	margin: 0px 15px 30px 0px;
	font-size: 14px;
	color: #c2c2c2;
	padding: 20px 30px;
}
.list_sprt1 li a {
	color: #515666;
	text-decoration: underline;
	font-size: 14px;
	margin-top: 10px;
}
</style>
