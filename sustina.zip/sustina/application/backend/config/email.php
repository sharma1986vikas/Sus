<?php
$config['smtp_host']="smtp.gmail.com";
$config['smtp_user']="testing@slinfy.com";
$config['smtp_pass']="slinfy007";
$config['smtp_port']="25";
$config['protocol'] = 'smtp';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;
?>