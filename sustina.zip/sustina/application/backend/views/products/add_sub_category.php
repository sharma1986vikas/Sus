<div class="content">
  <div class="header">
    <h1 class="page-title">Sub-Category</h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_sub_category">Mange subcategory</a> <span class="divider">/</span></li>
    <li class="active"><?php if($do=="add"){echo 'Add ';}else{echo 'Edit ';} ?>Category</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      <div class="well">
        <div id="myTabContent" class="tab-content">
          <div class="tab-pane active in" id="home">
            <form id="add" name="add" method="post" action="<?php echo base_url();;?><?php echo $this->router->class?>/add_sub_category_to_database" enctype="multipart/form-data">
              <?php if($do=="edit"){?>
              <input type="hidden" name="id" value="<?php echo $categorydata['id'];?>">
              <?php }?>
              <label>Category</label>
              <select name="parent_category" style="width:255px; height:35px;">
                <option value="">-Select category-</option>
                <?php $data = $this->products_model->get_all_category();
			    foreach($data as $key=>$val){?>
                <option value="<?php echo $val['id'];?>" <?php if($categorydata["parent_category"]==$val["id"]) echo "selected=selected"; ?> ><?php echo $val["category_name"];?></option>
                <?php }?>
              </select>
              <label>Sub Category</label>
              <input name="category_name" type="text" class="input-xlarge" value="<?php echo $categorydata['category_name'];?>"  />
              <div class="btn-toolbar">
                <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" />
                <a href="<?php echo base_url();?>products/manage_sub_category"  class="btn">Close</a>
                <div class="btn-group"> </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
