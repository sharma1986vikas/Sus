
<div class="content">
  <div class="header">
    <h1 class="page-title">Brand</h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo base_url();?>products/manage_brand">Brand</a> <span class="divider">/</span></li>
    <li class="active">
      <?php if($do =="add"){echo 'Add';}else{echo 'Edit';}?>
      Brand</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php 
			 $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") {?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      <div class="well">
        <div id="myTabContent" class="tab-content">
          <div class="tab-pane active in" id="home">
            <form id="add" name="add" method="post" action="<?php echo base_url();?><?php echo $this->router->class;?>/<?php echo $add_brand_to_database ;?>" enctype="multipart/form-data">
              <?php if($do=="edit"){?>
              <input type="hidden" name="brand_id" value="<?php echo $branddata['brand_id'];?>">
              <?php }?>
              <label>Name</label>
              <input name="brand_name" type="text" class="input_text" value="<?php echo $branddata['brand_name'];?>"  />
             
             
              <div class="btn-toolbar">
                <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" />
                <a href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_brand"  class="btn">Close</a>
                <div class="btn-group"> </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
