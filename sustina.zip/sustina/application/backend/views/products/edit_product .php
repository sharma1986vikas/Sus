<!--Product validations starts-->
<script src="<?php echo base_url();?>js/product_validation.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/upload_product_images.js" ></script>

<!--Product validations ends-->
<script>
 <?php $color_clone = $this->products_model->get_color();
 $size_clone = $this->products_model->get_size();
 ?>
 
 
//delete clone
function remove_data(id){
  $("#del_"+id).slideUp("fast",function(){
  		$("#del_"+id).remove();
  });
}

function archive_prop(){
	var count = $('.clone').length;
	if(count == 1){
		alert("You can delete this one atleast one product variation is required");
		return false;
	}
	else{
		return true;
	}
}

</script>
<div class="content">
  <div class="header">
    <h1 class="page-title">Product</h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li><a href="<?php echo base_url();?>products/manage_product">Product</a> <span class="divider">/</span></li>
    <li class="active"><?php if($do=="add"){echo 'Add';}else{echo 'Edit';}?> Product</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <?php  $error= $this->session->flashdata('errormsg');
			 $successmsg= $this->session->flashdata('successmsg');
			 if($error!="" || $successmsg!="") { ?>
      <div class="alert alert-info">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong> <font color='red'> <?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font></strong> </div>
      <?php } ?>
      
      <div class="alert alert-info" id="error"  style="display:none;"></div>
      
      <div class="well">
        <div id="myTabContent" class="tab-content">
          <div class="tab-pane active in" id="home">
            <?php // echo debug($productdata);?>
            <form  id="add" name="add" method="post" action="<?php echo base_url();?><?php echo $this->router->class;?>/<?php echo $add_product_to_database ;?>" enctype="multipart/form-data" onsubmit="check_arr();">
              <?php if($do=="edit"){?>
              <input type="hidden" name="product_id" value="<?php echo $productdata['product_id'];?>">
              <?php }?>
              <input type="hidden" name="do" value="<?php echo $do;?>" />
              <label>Title: </label>
              <input id="title" name="title" type="text" class="input_text" value="<?php echo $productdata['title'];?>"  />
              <label>Category:</label>
              <select id="category" name="category" style="width:220px; height:35px;" onchange="get_subcategory(this.value);">
                <option value="">-Select category-</option>
                <?php $data = $this->products_model->get_all_category();
			    foreach($data as $key=>$val){?>
                <option value="<?php echo $val['id'];?>" <?php if($productdata["category"]==$val["id"]) echo "selected=selected"; ?> ><?php echo $val["category_name"];?></option>
                <?php }?>
              </select>
              
              <input id="category"  type="hidden"  value="<?php echo $productdata["category"];?>"/>
              <label>Sub category: </label>
              <label><span id="subcat_data" style="width:400px;" >
                <select>
                  <option value="">-Select subcategory-</option>
                </select>
                </span> 
                
                <span style="padding-top: 13px;padding-left: 0px;" id="city_img" >
                <img src="<?php echo base_url();?>images/stateloader.gif" style="display:none;" /></span>
                <input id="subcategory"  type="hidden" style="float:left;" value="<?php echo $productdata["subcategory"];?>"/>
              </label>
              
              
              <label>Short description<span class="star"></span> : </label>
              <label class="txt1input">
                <textarea style="width: 340px;" rows="3" name="short_description" id="short_description"><?php echo $productdata['short_description'];?></textarea>
              </label>
             
              <label>Long description<span class="star"></span> : </label>
              <label class="txt1input">
                <textarea style="width: 340px;"  rows="6"  name="long_description" id="long_description"><?php echo $productdata['long_description'];?></textarea>
              </label>
             
             
              <label>Brand: </label>
              <label>
                <select id="brand" name="brand" style="width:220px; height:35px;">
                  <option value="">-Select brand-</option>
                  <?php $data = $this->products_model->get_all_brands();
			    foreach($data as $key=>$val){?>
                  <option value="<?php echo $val['brand_id'];?>" <?php if($productdata["brand"] == $val["brand_id"]) echo "selected=selected"; ?> ><?php echo $val["brand_name"];?></option>
                  <?php }?>
                </select>
              </label>
              
              <label>Price: </label>
              <label>
                <input name="price" id="price" type="text" class="input_text" value="<?php echo $productdata['price'];?>"  />
              </label>
              
              <label>Condition: </label>
              <label>
                <select id="condition" name="condition" style="width:220px; height:35px;">
                  <option value="">-Select condition-</option>
                  <?php //$data = $this->products_model->get_all_brands();
			    //foreach($data as $key=>$val){?>
                  <option value="1" <?php if($productdata["condition"] == 1){echo 'selected=selected';}?>>Condition 1</option>
                  <option value="2" <?php if($productdata["condition"] == 2){echo 'selected=selected';}?>>Condition 2</option>
                  <option value="3" <?php if($productdata["condition"] == 3){echo 'selected=selected';}?>>Condition 3</option>
                  <option value="4" <?php if($productdata["condition"] == 4){echo 'selected=selected';}?>>Condition 4</option>
                  <option value="5" <?php if($productdata["condition"] == 5){echo 'selected=selected';}?>>Condition 5</option>
                  <option value="6" <?php if($productdata["condition"] == 6){echo 'selected=selected';}?>>Condition 6</option>
                  <?php //}?>
                </select>
              </label>
              
              <label>Meta tag: </label>
              <label>
               <input name="meta_tag" id="meta_tag" type="text" class="input_text" value="<?php echo $productdata['meta_tag'];?>"  />
               <br/>
              <span style="font-size: 12px;">separate multiple meta tag with commas car,bike</span>
              </label>
              <label>Availability in stock: </label>
              <label><span style="color:#090">Yes</span>
                <input checked="checked" type="radio" name="product_availability" value="1" <?php if($productdata['product_availability'] == '1'){echo "checked = 'checked'";}?> />
                <span style="color:#f00"> No</span>
                <input type="radio" name="product_availability" value="0" <?php if($productdata['product_availability'] == '0'){echo "checked = 'checked'";}?> /></td>
			  </label>
              
              
              <?php if($do=="edit"){
				  //get all variations data related to this product 
				 $edit_variation  =  $this->products_model->get_variations_edit($productdata["product_id"]);
				 //echo debug($edit_varition);
				 //die;
				 if(count($edit_variation) !=0){
					 $j=0;foreach($edit_variation as $k=>$v){
				 ?>
              
              <label>Variations<span class="star"></span> : </label>
              <label>
              <div class="mukesh_outer_container clone" id="clone<?php echo $j;?>" >
                <div class="mukesh_outer_div"> 
                  <!--1st attribute starts-->
                  <div class="mukesh_left_div">Color</div>
                  <div class="mukesh_right_div">
                    <?php $color = $this->products_model->get_color();?>
                    <select name="color[<?php echo $j;?>]" id="color" class="color" style="width:220px; height:35px;"/>
                    <option value="">-Select color-</option>
                    <?php foreach($color as $key=>$val){?>
                    <option value="<?php echo $val["attribute_id"];?>"<?php if($val["attribute_id"] == $v["color_id"]){echo 'selected="selected"';}?>><?php echo $val["attribute_name"];?></option>
                    <?php }?>
                    </select>
                    <span class="txt_clone"> <a onclick="return archive_prop();"  href="<?php echo base_url();?><?php echo $this->router->class;?>/archive_product_property/<?php echo $v["id"]?>"> <img src="<?php echo base_url();?>/images/delete.png" title="Remove variation" /></a></span>
                    <div class="clear"></div>
                  </div>
                  <div class="clear"></div>
                  <!--1st attribute ends--> 
                  <!--2nd attribute starts-->
                  <div class="mukesh_left_div">Size</div>
                  <div class="mukesh_right_div">
                    <?php $size = $this->products_model->get_size();?>
                    <select  name="size[<?php echo $j;?>]" id="size" class="size" style="width:220px; height:35px;"/>
                    <option value="">-Select size-</option>
                    <?php foreach($size as $key=>$val){?>
                    <option value="<?php echo $val["attribute_id"];?>"<?php if($val["attribute_id"] == $v["size_id"] ){echo 'selected="selected"';}?>><?php echo $val["attribute_name"];?></option>
                    <?php }?>
                    </select>
                    <div class="clear"></div>
                  </div>
                  <div class="clear"></div>
                  <!--2nd attribute ends--> 
                  
                  <!--3nd attribute starts-->
                  <div class="mukesh_left_div">Quantity</div>
                  <div class="mukesh_right_div">
                    <input  type="text" name="quantity[<?php echo $j;?>]" class="quantity" id="quantity" value="<?php echo $v["quantity"]?>"  />
                    <div class="clear"></div>
                  </div>
                  <div class="clear"></div>
                  <!--3nd attribute ends--> 
                </div>
                <div class="clear"></div>
              </div>
              </label>
              <div class="clear"></div>
             <?php $j++; }}}else{?>
              <label>Variations<span class="star"></span> : </label>
              <label>
              <div class="mukesh_outer_container" id="clone">
                <div class="mukesh_outer_div"> 
                  <!--1st attribute starts-->
                  <div class="mukesh_left_div">Color</div>
                  <div class="mukesh_right_div">
                    <?php $color = $this->products_model->get_color();?>
                    <select name="color[0]" id="color" style="width:220px; height:35px;"  />
                    <option value="">-Select color-</option>
                    <?php foreach($color as $key=>$val){?>
                    <option value="<?php echo $val["attribute_id"];?>"<?php if($val["attribute_id"] == $productdata["color"]){echo 'selected="selected"';}?>><?php echo $val["attribute_name"];?></option>
                    <?php }?>
                    </select>
                    <div class="clear"></div>
                  </div>
                  <div class="clear"></div>
                  <!--1st attribute ends--> 
                  <!--2nd attribute starts-->
                  <div class="mukesh_left_div">Size</div>
                  <div class="mukesh_right_div">
                    <?php $size = $this->products_model->get_size();?>
                    <select  name="size[0]" id="size" style="width:220px; height:35px;"/>
                    <option value="">-Select size-</option>
                    <?php foreach($size as $key=>$val){?>
                    <option value="<?php echo $val["attribute_id"];?>"<?php if($val["attribute_id"] == $productdata["size"] ){echo 'selected="selected"';}?>><?php echo $val["attribute_name"];?></option>
                    <?php }?>
                    </select>
                    <div class="clear"></div>
                  </div>
                  <div class="clear"></div>
                  <!--2nd attribute ends--> 
                  
                  <!--3nd attribute starts-->
                  <div class="mukesh_left_div">Quantity</div>
                  <div class="mukesh_right_div">
                    <input type="text"  name="quantity[0]" id="quantity" value="<?php echo $productdata["quantity"]?>"/>
                    <div class="clear"></div>
                  </div>
                  <div class="clear"></div>
                  <!--3nd attribute ends--> 
                </div>
                <div class="clear"></div>
              </div>
              </label>
              <div class="clear"></div>
             
            <?php }?>
            <!------------------------------------------variations clone starts --------------------------->
             
			    <script>
				<?php if($do=="edit"){?>
				var counterUpload='';
				 var counterUpload = <?php echo $j ?>;
				<?php }else{?>
			 		var counterUpload = 1;
				<?php }?>	 
				 var limit = 20;
				
				 function addUpload(){
					 if (counterUpload == limit)  {
						  alert("You have reached the limit of adding " + counterUpload + " inputs");
					 }
					 else {
						  var newdiv = document.createElement('div');
						   newdiv.innerHTML = '<div class="mukesh_outer_container clone" id="del_' + counterUpload + '" >\n\
							  <div class="mukesh_outer_div1">\n\
								  <div class="mukesh_left_div">Color</div>\n\
								  <div class="mukesh_right_div">\n\
								  <select class="color" name="color[' + counterUpload + ']" id="color' + counterUpload + '" style="width:220px; height:35px;"  />\n\
								  <option value="">-Select color-</option>\n\
								   <?php foreach($color_clone as $key=>$val){?>
									<option value="<?php echo $val["attribute_id"];?>"<?php if($val["attribute_id"] == $productdata["color"] ){echo 'selected="selected"';}?>><?php echo $val["attribute_name"];?></option>\n\
									<?php }?>
									</select>\n\
								  <span class="txt_clone"><a href="javascript:void(0);" onclick="remove_data(' + counterUpload + ');">\n\
								  <img src="'+BASEURL+'/images/delete.png" title="Remove variation" /></a></span>\n\
								  <div class="clear"></div></div>\n\
								  <div class="clear"></div>\n\
								  <div class="mukesh_left_div">Size</div>\n\
								  <div class="mukesh_right_div">\n\
								  <select  class="size"  name="size[' + counterUpload + ']" id="size' + counterUpload + '" style="width:220px; height:35px;"/>\n\
								  <option value="">-Select size-</option>\n\
								   <?php foreach($size_clone as $key=>$val){?>
									<option value="<?php echo $val["attribute_id"];?>"<?php if($val["attribute_id"] == $productdata["color"] ){echo 'selected="selected"';}?>><?php echo $val["attribute_name"];?></option>\n\
									<?php }?>
									</select>\n\
								  <div class="clear"></div></div>\n\
								  <div class="clear"></div>\n\
								  <div class="mukesh_left_div">Quantity</div>\n\
								  <div class="mukesh_right_div">\n\
								 <input type="text"  class="quantity"  name="quantity[' + counterUpload + ']" id="quantity' + counterUpload + '" value="<?php echo $productdata["quantity"]?>"/>\n\
							      <div class="clear"></div></div>\n\
								  <div class="clear"></div>\n\
							   </div>\n\
							  <div class="clear"></div>\n\
						  </div><div class="clear"></div><span id="msg"></span>';
						  document.getElementById("dynamicInputUpload").appendChild(newdiv);
						  counterUpload++;
					 }
				 }
				</script>
              <!----------------------------------------variations clone ends ------------------------------------------->
              
               <!--div where clone appends starts-->
              <label></label>
              <label><div id="dynamicInputUpload"></div></label>
              <!--div where clone appends ends--> 
              <label></label>
             
              
              <label><a class="btn btn-primary" href="javascript:void(0);" onclick="addUpload();">+Variation</a></label>
              <div class="clear"></div>
              <div class="mukesh_upload_container">
              <div class="mukesh_outer_upload">
              <div class="tabbs" id="tabing1" >
             <!-- default images starts-->
              <?php 
			   if(isset($productdata['display_image']) && $productdata['display_image']!=""){?>
              <ul class="list_sprt1">
                <li id="display_image">
                  <p><img src="<?php echo $this->config->item("productimageurl");?><?php echo $productdata['display_image'];?>"  alt="<?php echo $productdata['display_image'];?>" height="170" width="270"  /></p>
                  <div class="clear"></div>
                </li>
                <input type="hidden" name="display_image" id="displayimage" value="<?php echo $productdata['display_image'];?>" />
              </ul>
              <?php }
			  else {?>
              <ul class="list_sprt1">
                <li id="display_image">
                  <p ><img src="<?php echo base_url();?>images/img_upload.png" height="65" width="65" alt="pic" /></p>
                  <div class="clear"></div>
                  <a href="javascript:void(0);" >Upload </a> 
                 </li>
                <input type="hidden" name="display_image" id="displayimage" value="" />
              </ul>
              
              <?php } ?>
               <!-- default images starts-->
              <div class="clear"></div>
             
              <!--other images starts-->
              <div class="tabbs" id="tabing2" >
              <ul class="list_sprt">
                <?php 
						  if($resultset['productimages']['0']['image_name']!=""){?>
                <li id="support_image1"> <img src="<?php echo $this->config->item("productimageurl");?><?php echo $resultset['productimages']['0']['image_name'];?>"  alt="<?php echo $resultset['productimages']['0']['image_name'];?>" height="95" width="120"  /> </li>
                <input type="hidden" name="productimage[]" id="supportimage1"  value="<?php echo $resultset['productimages']['0']['image_name'];?>" />
                <?php } else {?>
                <li id="support_image1"> <img src="<?php echo base_url();?>/images/img_upload.png" height="55" width="55" alt="pic" />
                  <div class="clear"></div>
                  <a href="javascript:void(0);" >Upload </a></li>
                <input type="hidden" name="productimage[]" id="supportimage1" value="" />
                <?php } ?>
                
                
                <?php if($resultset['productimages']['1']['image_name']!=""){?>
                <li id="support_image2"> <img src="<?php echo $this->config->item("productimageurl");?><?php echo $resultset['productimages']['1']['image_name'];?>"  alt="<?php echo $resultset['productimages']['1']['image_name'];?>" height="95" width="120"  /> </li>
                <input type="hidden" name="productimage[]" id="supportimage2" value="<?php echo $resultset['productimages']['1']['image_name'];?>" />
                <?php } else {?>
                <li id="support_image2"> <img src="<?php echo base_url();?>/images/img_upload.png" height="55" width="55" alt="pic" />
                  <div class="clear"></div>
                  <a href="javascript:void(0);" >Upload </a></li>
                <input type="hidden" name="productimage[]" id="supportimage2" value="" />
                <?php } ?>
               
               
                <?php if($resultset['productimages']['2']['image_name']!=""){?>
                <li id="support_image3"> <img src="<?php echo $this->config->item("productimageurl");?><?php echo $resultset['productimages']['2']['image_name'];?>"  alt="<?php echo $resultset['productimages']['2']['image_name'];?>" height="95" width="120"  /> </li>
                <input type="hidden" name="productimage[]" id="supportimage3" value="<?php echo $resultset['productimages']['2']['image_name'];?>" />
                <?php } else {?>
                <li id="support_image3"> <img src="<?php echo base_url();?>/images/img_upload.png" height="55" width="55" alt="pic" />
                  <div class="clear"></div>
                  <a href="javascript:void(0);" >Upload </a></li>
                <input type="hidden" name="productimage[]" id="supportimage3" value="" />
                <?php } ?>
                
				
				<?php if($resultset['productimages']['3']['image_name']!=""){?>
                <li id="support_image4"> <img src="<?php echo $this->config->item("productimageurl");?><?php echo $dataset['productimages']['3']['image_name'];?>"  alt="<?php echo $resultset['productimages']['3']['image_name'];?>" height="95" width="120"  /> </li>
                <input type="hidden" name="productimage[]" id="supportimage4" value="<?php echo $resultset['productimages']['3']['image_name'];?>" />
                <?php } else {?>
                <li id="support_image4"> <img src="<?php echo base_url();?>/images/img_upload.png" height="55" width="55" alt="pic" />
                  <div class="clear"></div>
                  <a href="javascript:void(0);" >Upload </a></li>
                <input type="hidden" name="productimage[]" id="supportimage4" value="" />
                <?php } ?>
               
                
              </ul>
              <div class="clear"></div>
            </div>
              <!--other images ends-->
              <div class="clear"></div>
            </div>
              
              </div>
              <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="btn-toolbar">
                <input class="btn btn-primary" name="submitbut" value="Submit" type="submit" onclick="return product_validation();" />
                <a href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_product"  class="btn">Close</a>
                <div class="btn-group"> </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url();?>js/ajaxupload.3.5.js" ></script>

