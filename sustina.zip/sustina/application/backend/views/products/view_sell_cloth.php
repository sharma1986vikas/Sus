
<div class="content">
  <div class="header">
    <h1 class="page-title">Sell cloth</h1>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo base_url();?>dashboard">Home</a> <span class="divider">/</span></li>
    <li class="active">Sell cloth</li>
  </ul>
  <div class="container-fluid">
    <div class="row-fluid">
      <div class="well">
        <table  class="table table1" width="100%">
          <!--<tr>
            <td ><div class="view1">Category :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_category_name($resultset['category_id']);?></div></td>
          </tr>
          <tr>
            <td ><div class="view1">Brand :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_brand_name($resultset['brand_id']); ?></div></td>
          </tr>-->
          <tr>
            <td ><div class="view1">Requested by :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $this->common->get_user_email($resultset['userid']);?></div></td>
          </tr>
          <tr>
            <td ><div class="view1">Requested date :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo date('Y-m-d',$resultset['created_on']);?></div></td>
          </tr>
          <tr>
            <td ><div class="view1">Price :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo $resultset['price_from']."-".$resultset['price_to'];?></div></td>
          </tr>
          <tr>
            <td align="right" class="label_form"><div class="view1"> Status :</div></td>
            <td><div class="view2" style="width:620px;"><?php echo ($resultset['status']=="1")?"<font color='green'>Accpeted</font>":"<font color='red'>Pending</font>"; ?></div></td>
          </tr>
        </table>
        <div tyle="margin-top:20px;"> <a class="btn btn-primary" href="<?php echo base_url();?><?php echo $this->router->class;?>/manage_sell_cloth">Close</a> </div>
      </div>
    </div>
  </div>
</div>
