<div class="form5">
<form id="add" name="add" method="post" action="<?php echo BASEURL;?>pages/update_page_to_database" enctype="multipart/form-data">
  <table width="890" border="0" cellpadding="5">
    <?php

			if($do=="edit")

			{

			?>
    <input type="hidden" name="id" value="<?php echo $resultset['id'];?>">
    <input type="hidden" name="page_name" value="<?php echo $resultset['page_name'];?>">
    <?php	

			}

			?>
    <tr>
      <td align="right" class="label_form" width="150px;">Page title: </td>
      <td width="700px"><input name="page_title" type="text" class="input_text" value="<?php echo $resultset['page_title'];?>"  />
        <br class="clear" /></td>
    </tr>
    <tr>
      <td align="right" class="label_form">Page content: </td>
      <td><textarea name="page_content" class="ckeditor">

        <?php echo $resultset['page_content'];?>

        </textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><div class="btn">
          <input class="button" name="submitbut" value="Save" type="submit" />
          <!--<a class="a_button" href="<?php echo base_url(); ?>page/manage_page">Cancel</a>--> 
        </div></td>
    </tr>
  </table>
</form>
