<?php 

class email_model extends CI_Model { 

 

    function __construct()

    {

        parent::__construct();

		//$this->load->model("store_model");

		$this->load->model("user_model");

	//	$this->load->model("newsletter_model");

    }

	

	/************************************************* Email functions starts **************************************************/	

		

	public function sendEmailToAllStores($emailarr)

	{

		$resultset=$this->store_model->getStoreData();

		foreach ($resultset as $emailkey => $emailval)

		{

			$this->email->clear();		

			$this->email->to($emailval["store_email"]);

			$this->email->from($this->config->item("adminemail"));

			$this->email->subject($emailarr["subject"]);

			$this->email->message($emailarr["message"]);

			$this->email->send();

		}

		

		$getdata["subject"]=$emailarr["subject"];

		$getdata["message"]=$emailarr["message"];

		$getdata["emailto"]=$emailarr["mailto"];

		$getdata["time"]=time();

		return $this->db->insert("ugk_email_history",$getdata);

	}

	

	public function sendEmailToAllAdvertisers($emailarr)

	{

		return true;  // because no section to advertiser is there so we are just making this function without body

	}

	

	public function sendEmailToAlltbl_users($emailarr)

	{

		$resultset=$this->user_model->getUserData();

		foreach ($resultset as $emailkey => $emailval)

		{
          $this->email->clear();		

			$this->email->to($emailval["store_email"]);

			$this->email->from($this->config->item("adminemail"));

			$this->email->subject($emailarr["subject"]);

			$this->email->message($emailarr["message"]);

			$this->email->send();

		}

		

		$getdata["subject"]=$emailarr["subject"];

		$getdata["message"]=$emailarr["message"];

		$getdata["emailto"]=$emailarr["mailto"];

		$getdata["time"]=time();

		return $this->db->insert("ugk_email_history",$getdata);

	}

	

	public function getEmailHistory($searchdata=array())

	{

		if(!isset($searchdata["page"]) || $searchdata["page"]=="")

		{

			$searchdata["page"]=0;	

		}

	    if(!isset($searchdata["countdata"]))

		{	

			if(isset($searchdata["per_page"]) && $searchdata["per_page"]!="")

			{

				$recordperpage=$searchdata["per_page"];	

			}

			else

			{

				$recordperpage=1;

			}

			if(isset($searchdata["page"]) && $searchdata["page"]!="")

			{

				$startlimit=$searchdata["page"];	

			}

			else

			{

				$startlimit=0;

			}

		}

		

		

		$this->db->select("*");

		$this->db->from("ugk_email_history");

		if(isset($searchdata["search"]) && $searchdata["search"]!="search" && $searchdata["search"]!="")

		{

			$this->db->like('ugk_email_history.subject', $searchdata["search"]);

			$this->db->or_like('ugk_email_history.emailto', $searchdata["search"]);

		}	

		if(!isset($searchdata["countdata"]))

		{

			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))

			{

				$this->db->limit($recordperpage,$startlimit);

			}

		}

		$query=$this->db->get();

		$resultset=$query->result_array();;

		return $resultset;

	}

	

	public function getIndividualEmailHistory($emailid)

	{

		$this->db->select("*");

		$this->db->from("ugk_email_history");

		$this->db->where(array("id"=>$emailid));

		$query=$this->db->get();

		$resultset=$query->row_array();;

		return $resultset;

	}

	

	public function sendIndividualEmail($emailarr){
      // echo "<pre>";
      // print_r($emailarr);die;
      $this->load->library('email', $config);
      $this->load->library('parser', $config);
	  $this->email->set_newline("\r\n");
	  $this->email->to($emailarr["to"]);// change it to yours
      $this->email->from($config['smtp_user'], 'Food Stop');
	  $this->email->subject($emailarr["subject"]);
	  $this->email->message($emailarr["message"]);
	  $result = $this->email->send();
	  if($result){
	   	$err=0;
	  }
 	  else{
		//show_error($this->email->print_debugger());
		 $this->email->print_debugger();
		 $err=1;
	  }
	   return $err;
 }
	/*public function sendIndividualEmail($emailarr)

	{

		$this->email->clear();

	    $config["mailtype"]="html";

		$this->email->initialize($config);		

	    $this->email->to($emailarr["to"]);

		$this->email->from('noreply@socialtyer.com', 'Social Tyer');

		$this->email->subject($emailarr["subject"]);

		$this->email->message($emailarr["message"]);

		if($this->email->send())

		{

			echo 'Your email was sent, successfully.';

		}

		

		else

		{

			show_error($this->email->print_debugger());

		}

	}*/

	
	public function sendEmailToAllNewsletters($emailarr)

	{

		$resultset=$this->newsletter_model->getNewsletterdata();

		foreach ($resultset as $emailkey => $emailval)

		{

			

			

			$this->email->clear();		

			$this->email->to($emailval["user_email"]);

			$this->email->from($this->config->item("adminemail"));

			$this->email->subject($emailarr["subject"]);

			$this->email->message($emailarr["message"]);

			$this->email->send();

		}

		

		$getdata["subject"]=$emailarr["subject"];

		$getdata["message"]=$emailarr["message"];

		$getdata["emailto"]=$emailarr["mailto"];

		$getdata["time"]=time();

		return $this->db->insert("ugk_email_history",$getdata);

	}

	
public function send_contact_email($emailarr)
	{
	    $this->email->clear();
		$config["mailtype"]="html";
            
		$this->email->initialize($config);
		$this->email->to($emailarr["to"]);
		$this->email->from($emailarr["email"]);
		$this->email->subject($emailarr["subject"]);
		$this->email->message($emailarr["message"]);
                
        
		
		
		
		if(isset($emailarr["attachment"]))
		{   
		    $file =  './attachments/'.$emailarr["attachment"];
            $this->email->attach($file);
			}
		if($this->email->send())
		{
		  return true;	
		}
		else
		{
			 return false;
		}
		/*{
			echo 'Your email was sent, successfully.';
		}
		else
		{
			show_error($this->email->print_debugger());
		}*/		
	}


	

	/************************************************* Email function ends **************************************************/

	

}