<?php 
class common extends CI_Model {
    function __construct()
    {
        parent::__construct();
		$http="";
		if(isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"]=="on")
		{
			$http="http://";	
		}
		else
		{
			$http="https://";	
		}
		$prevurl=array("prevurl"=>base_url());
		$this->session->set_userdata($prevurl);
		$this->session->set_userdata("currenturl",base_url());
    }
	
	function create_unique_slug($string,$table,$field,$key=NULL,$value=NULL)
	{
		$t =& get_instance();
		$slug = url_title($string);
		$slug = strtolower($slug);
		$i = 0;
		$params = array ();
		$params[$field] = $slug;
	 
		if($key)$params["$key !="] = $value;
	 
		while ($t->db->where($params)->get($table)->num_rows())
		{  
			if (!preg_match ('/-{1}[0-9]+$/', $slug ))
				$slug .= '-' . ++$i;
			else
				$slug = preg_replace ('/[0-9]+$/', ++$i, $slug );
			 
			$params [$field] = $slug;
		}  
		
		return $slug;  
	}
	//RG function to ensure uniq random entry in a table
	public function user_uniq($table, $column, $length){
	  $uniq = $this->random_generator($length);
	  
	  $this->db->select("*");
	  $this->db->from($table);
	  $this->db->where($column,$uniq);
	  $query=$this->db->get();
	  $resultset = $query->row_array();
	  if(count($resultset) == 0){
		  return $uniq;
	  }
	  else{return user_uniq($table, $column, $length);}
	 /* $sql = "SELECT count(*) from $table where $column='$uniq'";
	  $exec = mysql_query($sql);
	  list($num) = mysql_fetch_row($exec);
	  if($num == 0){return $uniq;}
	  else{return user_uniq($table, $column, $length);}*/
	 }

	public function get_extension($file_name){
		$ext = explode('.', $file_name);
		$ext = array_pop($ext);
		//print_r($this->config->item("allowedimages"));die;
		if(!in_array($ext,$this->config->item("allowedimages"))){
			$this->session->set_flashdata("errormsg","Wrong file format only jpg,png,gif allowded");
			//redirect(base_url()."pages/manage_page/contact/edit");
		}
		else{
			return strtolower($ext);
		}
	}
	
	function validate_email($email)
	{
		return filter_var($email, FILTER_VALIDATE_EMAIL);	
	}
	
	//to check login status
	public function check_authentication() {
		
	  $controllername=$this->router->class;
	  $methodname=$this->router->method;
	  
	  if(($controllername=="login") && $methodname!="logout")
	  {
  		 $username=$this->session->userdata("username");
  		 if(isset($username) && $username!="")
  		 {
  		  redirect(base_url()."dashboard"); 
  		 }
 	  }
	  
 	 if($controllername !="login"){
		// echo $this->config->item("usertype");die;
	  	 if($this->config->item("usertype")=="admin"){
			  $this->db->select("username");
			  $this->db->from("admin");
			  $query=$this->db->get();
			  $resultset=$query->row_array();
			 
			  if($resultset["username"] != $this->session->userdata("username")){
				 $this->session->set_flashdata("errormsg","Please login to access admin panel first");
				 redirect(base_url()."login/"); 
			  }
		 }
	   }
	}
	public function checkpasswordvalidity($arr)
	{
		$this->db->select("*");
		$this->db->from("admin");
		$this->db->where("username",$this->session->userdata("username"));
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$result = $query->row_array();
		
		if($this->validateHash($arr["oldpassword"],$result["password"])){
			return false;	
		}	
		else{
			return true;	
		}
		
		/*$this->db->select("id");
		$this->db->from("admin");
		$this->db->where("password",$arr["oldpassword"]);
		$query=$this->db->get();
		$result=$query->row_array();
		if($result["id"]=="")
		{
			return true;	
		}	
		else
		{
			return false;	
		}*/
	}
	//update user profile data
	public function update_profile($arr)
	{
		//2736f2f2cb760b84488b342f26e6210e:xl
		$newarr["password"] = $this->salt_password(array("password" => $arr["newpassword"]));
		if(isset($arr["username"]) && $arr["username"]!="")
		{
			$newarr["username"] = $arr["username"];
		}
		return $this->db->update("admin",$newarr);
	}
	
	//remove parameter from url
	public function removeUrl($parametername,$querystring)
	{
		$newquerystring="";
		$querystring=explode("&",$querystring);
			
		foreach($querystring as $key=>$val)
		{
			$newval=explode("=",$val);
			if($newval[0]!="")
			{
				if($newval[0]!=$parametername)
				{
					$newquerystring.="&".$newval[0]."=".$newval[1];	
				}
			}
		}		
		
		$newquerystring=substr($newquerystring,1,strlen($newquerystring));
		
		return $newquerystring;
	}
	
	public function addUrl($parametername,$parametervalue,$querystring)
	{
		
		//echo $parametername."=".$parametervalue;		
		$querystring=explode("&",$querystring);
		$newquerystring="";
		$i=0;
		if(count($querystring)!=0 && $querystring[0]!="")
		{
			foreach($querystring as $key=>$val)
			{
					$valnew=explode("=",$val);
					if($valnew[0]!=$parametername)
					{
						$newquerystring.="&".$valnew[0]."=".$valnew[1];
					}
					else
					{
						$newquerystring.="&".$parametername."=".$parametervalue;	
						$i=1;
					}
			}
		}
		if($i==0)
		{
				$newquerystring.="&".$parametername."=".$parametervalue;
		}
		return $newquerystring=substr($newquerystring,1,strlen($newquerystring));
	}
	//to checl user login status 	
	public function is_logged_in(){
		
   		 $is_logged_in = $this->session->userdata('is_logged_in');
		 //echo $is_logged_in;die;
		 if($is_logged_in != 1){
			$this->session->set_flashdata("errormsg","Authentication failed. You need to login to access this page");
			redirect(base_url()."home/signin");
			return false;
       		// echo 'You need to login to access this page';
       		 //die();
  		 }
		 else{
			  $this->db->select("*");
			  $this->db->from("tbl_users"); 
			  $this->db->where(array("id"=>$this->session->userdata("userid"),"user_status <>"=>"4"));
			  $result=$this->db->get();
			  $row=$result->row_array();
			  $num_row = $result->num_rows();
		     
		       $err=0;
			  if($num_row == 0){
			  	 $err =1; 
			  }
			  else
			  {
				   $data_array= array("userid"=>$row['id'],"is_logged_in",true);
				   $this->session->set_userdata($data_array);
				   $err=0;
				  // echo "hii";die;
				  // redirect(base_url()."users/my_page");
			  }
			  if($err==1)
			  {
			   redirect(base_url()."home/signin");
			  }
		 }
	}
	
	public function checkUserFacebookLogin($email,$fbid)
	{
		$this->db->select("*");
		$this->db->from("tbl_users");
		$this->db->where(array("email" => $email,"fbid" => $fbid,"user_status <>"=>4));
	    $result = $this->db->get();
		
	 	$countrows = $result->num_rows();
	
		if($countrows == 0)
		{
			return $countrows;	
	    }
		 else
		 {
			$result = $result->row_array();
			if($result["user_status"]=="1")
			{
				$this->session->set_userdata("userid",$result["id"]);
				$this->session->set_userdata("fbid",$result["fbid"]);
				$this->session->set_userdata("email",$result["email"]);
				$this->session->set_userdata("user_type",$result["user_type"]);
				$this->session->set_userdata("is_logged_in",true);
				$this->session->set_userdata("user_uniq",$result["user_uniq"]);
				return true;
			}
			else
			{
				$this->session->set_flashdata("errormsg","Your account is currently inactive. Please contact admin.");	
				return false;
			}
		}
	}
	
	public function checktwitterlogin($name,$tid){
		$this->db->select("*");
		$this->db->from("tbl_users");
		$this->db->where(array("username" => $name,"tid"=>$tid,"user_status <>"=>4));
	    $result=$this->db->get();
	 	$countrows=$result->num_rows();
		if($countrows == 0){
			return $countrows;	
		}
		 else
		 {
			$result = $result->row_array();
			if($result["user_status"] == "1")
			{
				$this->session->set_userdata("userid",$result["id"]);
				$this->session->set_userdata("tid",$result["tid"]);
				$this->session->set_userdata("email",$result["email"]);
				$this->session->set_userdata("user_type",$result["user_type"]);
				$this->session->set_userdata("is_logged_in",true);
				$this->session->set_userdata("user_uniq",$result["user_uniq"]);
				return true;
			}
			else
			{
				$this->session->set_flashdata("errormsg","Your account is currently inactive. Please contact admin.");	
				return false;
			}
		}
	}
	//login user and set session 
	public function authenticateUserLogin($loginarray)
	{
		$this->db->select("*");
		$this->db->from("tbl_users");
		$this->db->where(array("email" => $loginarray["email"],"user_status <>"=>"4"));
		$result=$this->db->get();
		//echo $this->db->last_query();
		$countrows=$result->num_rows();
		$result=$result->row_array();
		
		if($loginarray["email"] == ""){
			$this->session->set_flashdata("errormsg","Authentication failed. Invalid Email");
			return false;	
		}
		else if($loginarray["password"] == ""){
			$this->session->set_flashdata("errormsg","Authentication failed. Invalid Password");
			return false;	
		}
		else if($result["user_status"] ==0){
			$this->session->set_flashdata("errormsg","Authentication failed. Your account is inactive/not approved");
			return false;	
		}
		
	    else if($this->validateHash($loginarray["password"],$result["password"]))
		{
			$this->session->set_userdata("userid",$result["id"]);
		    $this->session->set_userdata("email",$result["email"]);
			$this->session->set_userdata("user_type",$result["user_type"]);
			$this->session->set_userdata("is_logged_in",true);
			$this->session->set_userdata("user_uniq",$result["user_uniq"]);
			return true;
		}
		else
		{
			$this->session->set_flashdata("errormsg","Authentication failed. Invalid Email/password or your account is not Verified Yet");
			return false;	
		}
	}
	//make encrypted. password
	public function salt_password($arr){
		 //echo "pass is =".($arr["password"]);die;
		 $salt_key = $this->common->random_generator(2);
		 $pas = md5($salt_key. $arr["password"]);
		 $column = ':';
		 return $pas.$column.$salt_key;
	}
	
	public function validateHash($password, $hash)
	{
		$hashArr = explode(':', $hash);
		if(md5($hashArr[1].$password) === $hashArr[0])
		{
			//echo "matched";die;
			return true;	
		}
		else
		{//
			//echo "not matched";die;
			return false;	
		}
	}
	public function check_price($arr){
		$this->db->select('*');
		$this->db->from('tbl_category_brand_price');
		if($arr["price_id"] == ""){
			$this->db->where(array("category_id" => $arr["category_id"],"brand_id" => $arr["brand_id"],"price_from" => $arr["price_from"],"price_to" => $arr["price_to"],"price_status <>" => "4"));
		}
		else{
			$this->db->where(array("category_id" => $arr["category_id"],"brand_id" => $arr["brand_id"],"price_from" => $arr["price_from"],"price_to" => $arr["price_to"],"price_status <>" => "4","price_id <>" => $arr["price_id"]));
		}
		$query = $this->db->get();
		//$this->db->last_query();
		$resultset = $query->num_rows();
		
		if($resultset==0)
		{
			return true;
	    }
		else
		{
			return false;	
		}	
	}
	//to empty session values
	public function empty_filed()
	{
		return  $this->session->unset_userdata('tempdata'); 
	}
	
	//check email already exists
	public function validate_email_exist($arr){
		
		$this->db->select('email');
		$this->db->from('tbl_users');
		if($arr["id"] == ""){
			$this->db->where(array("email" => $arr["email"],"user_status <>" => "4"));
		}
		else{
			$this->db->where(array("email" => $arr["email"],"user_status <>" => "4","id <>" => $arr["id"]));
		}
		$query = $this->db->get();
		//$this->db->last_query();
		$resultset = $query->num_rows();
		
		if($resultset==0)
		{
			return true;
	    }
		else
		{
			return false;	
		}	
	}
	
	public function validate_forgot_email_exist($arr){
		
		$this->db->select('email');
		$this->db->from('tbl_users');
		if($arr["id"] == ""){
			$this->db->where(array("email" => $arr["email"],"user_status <>" => "4"));
		}
		else{
			$this->db->where(array("email" => $arr["email"],"user_status <>" => "4","id <>" => $arr["id"]));
		}
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset = $query->num_rows();
		
		if($resultset==0)
		{
			return false;
	    }
		else
		{
			return true;	
		}	
	}
			
	//check user name already exists
	public function validate_username_exist($arr){
		
		$this->db->select("username");
		$this->db->from("tbl_users");
		
		if($arr["id"] == ""){
			$this->db->where(array("username" => $arr["username"],"user_status <>" => "4"));
		}
		else{
			$this->db->where(array("username" => $arr["username"],"user_status <>" => "4","id <>" => $arr["id"]));
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		$resultset = $query->num_rows();
		
		if($resultset==0)
		{
			return true;
	    }
		else
		{
			return false;	
		}	
	}
	public function random_generator($digits){
    // function starts
		srand((double) microtime() * 10000000);
		$input = array("A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a", "b", "c", "d", "e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z");
		$random_generator="";
		// Initialize the string to store random numbers
		for ($i=1; $i<=$digits; $i++) {
			// Loop the number of times of required digits
			if (rand(1,2) == 1) {
				// to decide the digit should be numeric or alphabet
				// Add one random alphabet
				$rand_index = array_rand($input);
				$random_generator .=$input[$rand_index];
				// One char is added
			} else {
				// Add one numeric digit between 1 and 9
				$random_generator .=rand(1,9);
				// one number is added
			}
			// end of if else
		}
		// end of for loop
		return $random_generator;
	}

		public function check_brand_name($arr){
			
			$this->db->select("brand_name");
			$this->db->from("tbl_brand");	
			if($arr["brand_id"] == ""){
				$this->db->where(array("brand_name"=>$arr["brand_name"],"brand_status <>" => "4"));
			}
			else{
				$this->db->where(array("brand_name"=>$arr["brand_name"],"brand_status <>" => "4","brand_id <>" => $arr["brand_id"]));
			}
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->result_array();
			//echo count($result);
			if(count($result)==0)
			{
				return true;	
			}
			else
			{
				return false;	
			}
		}
		
	public function check_category_name($arr){
			
			$this->db->select("category_name");
			$this->db->from("tbl_categories");	
			if($arr["id"] == ""){
				$this->db->where(array("category_name"=>$arr["category_name"],"category_status <>" => "4"));
			}
			else{
				$this->db->where(array("category_name"=>$arr["category_name"],"category_status <>" => "4","id <>" => $arr["id"]));
			}
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->result_array();
			//echo count($result);
			if(count($result)==0)
			{
				return true;	
			}
			else
			{
				return false;	
			}
		}
		
			public function check_sub_category_name($arr){
			
			$this->db->select('*');
			$this->db->from('tbl_categories');
			if($arr["id"] == ""){
				$this->db->where(array('category_name' => $arr["category_name"],"parent_category"=>$arr["parent_category"],"category_status <>"=>"4"));
			}
			else{
				$this->db->where(array('category_name' => $arr["category_name"],"parent_category"=>$arr["parent_category"],"category_status <>"=>"4","id <>" => $arr["id"]));
			}
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->result_array();
			//echo count($result);
			if(count($result)==0)
			{
				return true;	
			}
			else
			{
				return false;	
			}
		}
		
		public function get_category_name($id){
			$this->db->select('category_name');
			$this->db->from('tbl_categories');
			$this->db->where(array('id' => $id,"parent_category"=>0,"category_status <>"=>"4"));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->row_array();
			return $result["category_name"];
		}
		
		public function get_subcategory_name($id){
			$this->db->select('category_name');
			$this->db->from('tbl_categories');
			$this->db->where(array('id' => $id,"parent_category <>"=>0,"category_status <>"=>"4"));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->row_array();
			return $result["category_name"];
		}
		
		public function get_brand_name($id){
			$this->db->select('brand_name');
			$this->db->from('tbl_brand');
			$this->db->where(array('brand_id' => $id,"brand_status <>"=>"4"));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->row_array();
			return $result["brand_name"];
		}
		public function get_condition_name($id){
			$this->db->select('condition_name');
			$this->db->from('tbl_condition');
			$this->db->where(array('condition_id' => $id,"condition_status <>"=>"4"));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->row_array();
			return $result["condition_name"];
		}
		
		
		public function check_property_name($arr){
			
			$this->db->select("attribute_name");
			$this->db->from("tbl_attributes");	
			if($arr["type"] =="add"){
				$this->db->where(array("attribute_name"=>$arr["attribute_name"],"attribute_status <>" => "4"));
			}
			else{
				$this->db->where(array("attribute_name"=>$arr["attribute_name"],"attribute_status <>" => "4","attribute_id <> " => $arr["attribute_id"]));
			}
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->result_array();
			//echo count($result);
			if(count($result)==0)
			{
				return true;	
			}
			else
			{
				return false;	
			}
		}
		
		public function get_user_email($id){
			$this->db->select("email");
			$this->db->from("tbl_users");	
			$this->db->where(array("id"=>$id,"user_status <>" => "4"));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->row_array();
			return $result["email"];
		}
		public function get_pdt_id_by_slug($id){
			$this->db->select("product_id");
			$this->db->from("tbl_product");	
			$this->db->where(array("product_slug"=>$id,"product_status <>" => "4"));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result=$result->row_array();
			return $result["product_id"];
		}
		public function check_referal_code($arr){
			//debug($arr);die;
			$this->db->select("user_uniq");
			$this->db->from("tbl_users");	
			$this->db->where(array("user_uniq" => $arr["referal_code"]));
			$result=$this->db->get();
			//echo  $this->db->last_query();die;
			$result = $result->row_array();
			//echo count($result);
			if(count($result)==0)
			{
				return false;	
			}
			else
			{
				return true;	
			}
		}

}
if(FRONTPATH !="frontend")
{
	$common= new common;	
	$common->check_authentication();
}