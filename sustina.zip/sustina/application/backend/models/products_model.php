<?php 
class products_model extends CI_Model {
    function __construct()
    {
        parent::__construct();
    }
	
	/***************************************************Product functions start***************************************/
	public function getProductImagesOfProduct($productid)
  {
   $this->db->select("*,tbl_product_images.id as image_id");
   $this->db->from("tbl_product_images");
   $this->db->join("tbl_product","tbl_product_images.product_id=tbl_product.product_id");
   $this->db->where(array("tbl_product.product_status <>"=>4,"tbl_product.product_id"=>$productid));
   $result=$this->db->get();
   //echo $this->db->last_query();die;
   return $result->result_array();
  }
  
	public function getProductData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
		 if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
	
		$sql= "select * from tbl_product where 1=1";	
		
		if(isset($searcharray["category"]) && $searcharray["category"]!="")
		{
			$sql.= " and  tbl_product_category.category_id = '".$searcharray["category"]."'";
		}
		if(isset($searcharray["subcategory"]) && $searcharray["subcategory"]!="")
		{
			$sql.= " and tbl_product_sub_categories.subcategory_id = '".$searcharray["subcategory"]."'";
		}
		if(isset($_GET['store'])){
			
			$sql.= " and tbl_product.user_uniq	 = '".$_GET['store']."'";
		}
		if(isset($searcharray["search"]) && $searcharray["search"]!="search" && $searcharray["search"]!="")
		{
			$sql.= " and (ugk_stores.firstname like '%".trim($searcharray["search"])."%' or tbl_product.product_name like '%".trim($searcharray["search"])."%')";
				}
		if(isset($searcharray["status"]) && $searcharray["status"]!="")
		{
			$sql.= " and tbl_product.product_status = '".$searcharray["status"]."'";
		}
		else{
			$sql.= " and tbl_product.product_status = '1'";
		}
		
		
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$sql.=" limit  $startlimit,$recordperpage";
			}
		}
		$query = $this->db->query($sql);
		$resultset=$query->result_array();
		 return $resultset;
	}
	
	
	
	
	
	
	/*{public function getProductData_old($searcharray=array())
			//debug($searcharray);die;
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		$searchdata=array("status"=>"product_status","store"=>"store_id","category"=>"tbl_categories.id");
		$this->db->select("*,tbl_product.id as productid");
		$this->db->from("tbl_product");
		$this->db->join("ugk_stores","ugk_stores.id=tbl_product.user_uniq");
		
		$this->db->join("tbl_product_category","tbl_product_category.product_id=tbl_product.id");
		$this->db->join("tbl_categories","tbl_product_category.category_id=tbl_categories.id");
		$this->db->join("tbl_product_sub_categories","tbl_product_sub_categories.product_id=tbl_product.id");	
		
		
		if(isset($searcharray["category"]) && $searcharray["category"]!="")
		{
			$where=array("tbl_product_category.category_id"=>$searcharray["category"]);
			$this->db->where($where);
		}
		if(isset($searcharray["subcategory"]) && $searcharray["subcategory"]!="")
		{
			$where=array("tbl_product_sub_categories.subcategory_id"=>$searcharray["subcategory"]);
			$this->db->where($where);
		}
		
		if($this->session->userdata("consumer_id") <> ''){
			
			$this->db->where(array("tbl_product.user_uniq "=>$this->session->userdata("consumer_id")));
			
		}
		if(isset($searcharray["search"]) && $searcharray["search"]!="search" && $searcharray["search"]!="")
		{
			$this->db->like(array("ugk_stores.firstname"=>$searcharray["search"]));
		    $this->db->or_like('tbl_product.product_name',$searcharray["search"]);
		}
		
		
		if(isset($searcharray["status"]) && $searcharray["status"]!="")
		{
			$where=array("tbl_product.product_status"=>$searcharray["status"]);
			$where=array("tbl_product.product_status <> "=>"4");
			$this->db->where($where);
		}
		else{
			$where=array("tbl_product.product_status <> "=>"4");
			$this->db->where($where);
		}
		$this->db->group_by(array("tbl_product.id"));
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		
		$query=$this->db->get();
		$resultset=$query->result_array();
	    //echo $this->db->last_query();die;
		return $resultset;	
	}*/
	
	public function time_ago($ptime) {
    $etime = time() - $ptime;
     
    if ($etime < 1) {
        return '0 seconds';
    }
     
    $interval = array( 12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
                );
     
    foreach ($interval as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . ' ' . $str . ($r > 1 ? 's' : '');
        }
    }
}
	
		
	
	
	public function getProductSubCategory($productid)
	{
		$this->db->select("category_name");
		$this->db->from("tbl_categories");
		$this->db->join("tbl_product_sub_categories","tbl_product_sub_categories.subcategory_id=tbl_categories.id");
		$this->db->where(array("tbl_product_sub_categories.product_id"=>$productid));
		$query=$this->db->get();
		$resultset=$query->row_array();
		return $resultset["category_name"];	
	}
	
	public function getProductSubCategoryId($productid)
	{
		$this->db->select("tbl_categories.id as subcategory");
		$this->db->from("tbl_categories");
		$this->db->join("tbl_product_sub_categories","tbl_product_sub_categories.subcategory_id=tbl_categories.id");
		$this->db->where(array("tbl_product_sub_categories.product_id"=>$productid));
		$query=$this->db->get();
		$resultset=$query->row_array();
		return $resultset["subcategory"];	
	}
	
	
	public function getSubCategoryFromCategory($search=array())
	{
		$i=0;
		$categoryid=$search["categoryid"];
		$this->db->select("*");
		$this->db->from("tbl_categories");
		$this->db->where("parent_category",$categoryid);
		if(isset($search["type"]) && $search["type"]!="")
		{
			$this->db->where(array("tbl_categories.category_status"=>"1"));	
		}
		$this->db->where(array("tbl_categories.category_status <>"=>"4"));	
		$query=$this->db->get();
		$resultset=$query->result_array();
		
		if(isset($search["type"]) && $search["type"]=="json")
		{
			foreach($resultset as $key=>$val)
			{
				$subcategory[$i]["id"]=$val["id"];
				$subcategory[$i]["category_name"]=$val["category_name"];
				$i++;	
			}	
			
			return json_encode($subcategory);
		}
		else if(isset($search["type"]) && $search["type"]=="array")
		{
			foreach($resultset as $key=>$val)
			{
				$subcategory["id"][$i]=$val["id"];
				$subcategory["category_name"][$i]=$val["category_name"];
				$i++;	
			}	
			
			return $subcategory;
		}
		else
		{
			return $resultset;
		}
	}
	
	public function getIndividualProductData($productid)
	{
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->where(array("tbl_product.product_status <> "=>"4","tbl_product.product_id"=>$productid));
		$query=$this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->row_array();
		return $resultset;
	}
	public function get_product_detail_slug($productid)
	{
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->where(array("tbl_product.product_status <> "=>"4","tbl_product.product_slug"=>$productid));
		$query=$this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->row_array();
		return $resultset;
	}
	public function get_categoryslug_byid($id)
	{
		$this->db->select("slug");
		$this->db->from("tbl_categories");
		$this->db->where(array("id" => $id ,"parent_category" =>0,"category_status <> "=>"4"));
		$query=$this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->row_array();
		return $resultset["slug"];
	}
	
	public function get_total_product_likes($id)
	{
		$this->db->select("*");
		$this->db->from("tbl_favorite");
		$this->db->where(array("product_id" => $id ,"status <> "=>"4"));
		$query=$this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->result_array();
		return count($resultset);
	}
	
	public function is_fav_product($id){
		$this->db->select("*");
		$this->db->from("tbl_favorite");
		$this->db->where(array("status <> "=>"4","tbl_favorite.product_id"=>$id));
		$query=$this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->row_array();
		if($resultset){
			return true;
		}
		else{
			return false;
		}
	}
	public function get_product_snidel($arr)
	{
		$to =(time() - 30*24*3600);
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->where(array("category" => $arr["category"],"product_id <> " => $arr["product_id"],"product_status <> " => "4","product_created_time >=" =>$to));
		$this->db->order_by("product_id","RANDOM");
		$this->db->limit(4,0);
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->result_array();
		return $resultset;
	}
	public function get_recommended_product_by_allcategory($arr)
	{
		$to =(time() - 30*24*3600);
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->where(array("product_id <> " => $arr["product_id"],"product_status <> " => "4","product_created_time >=" =>$to));
		$this->db->order_by("product_id","RANDOM");
		$this->db->limit(4,0);
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$resultset = $query->result_array();
		return $resultset;
	}
	
	//function to call on onchange state
	 public function get_category_byid($id){
	   //echo $id;
		$this->db->select("*");
		$this->db->from("tbl_categories");
		$this->db->where("parent_category",$id);
		$where=array("category_status <>" =>4);
		$this->db->where($where);
		$query = $this->db->get();
	  	//echo $this->db->last_query();die;
		$result=$query->result_array();
		//echo count($result);
		if(count($result) !=0 && count($result) > 0)
		{
			$data  = $result;	
		}
		else
		{
			$data  =0;	
		}
		return $data;
	}
	public function add_edit_product($arr)
	{
		//debug($arr);die;
		if($arr["product_id"]=="")
		{
			return $this->db->insert("tbl_product",$arr);	
		}	
		else
		{
			$id = $arr["product_id"];
			unset($arr["product_id"]);
			$this->db->where("product_id",$id);
			return $this->db->update("tbl_product",$arr);
		    //echo $this->db->last_query();die;	
		}
	}
	
	public function add_product_variations($arr,$do){
		
		if($do == "add"){//add varitions to database
			foreach($arr["color"] as $k=>$v){
				if($v <> ""){
					$data["product_id"] = $arr["product_id"];
					$data["color_id"] = $v;
					$data["size_id"] = $arr["size"][$k];
					$data["quantity"] = $arr["quantity"][$k]; 
					$data['created_time'] = time();
					$data['status'] = 1;
					$this->db->insert("tbl_product_attribute_relation",$data);
					//echo $this->db->last_query();die;
				}
			}
		}
		else{//update varitions to database
			$this->db->where("product_id",$arr["product_id"]);
			//$arr = array("status" => 4);
			$this->db->delete("tbl_product_attribute_relation");
			//echo $this->db->last_query();die;
			foreach($arr["color"] as $k =>$v){
				if($v <> ""){
					$data["product_id"] = $arr["product_id"];
					$data["color_id"] = $v;
					$data["size_id"] = $arr["size"][$k];
					$data["quantity"] = $arr["quantity"][$k]; 
					$data['created_time'] = time();
					$data['status'] = 1;
					$this->db->insert("tbl_product_attribute_relation",$data);
					//echo $this->db->last_query();die;
				}
			}
		}
	}

	public function get_variations_edit($id){
		//get all varoations data on edit 
		$this->db->select("*");
		$this->db->from("tbl_product_attribute_relation");
		$this->db->where("product_id",$id);
		$query = $this->db->get();
	  	//echo $this->db->last_query();die;
		$result = $query->result_array();
		return $result;
	}
	
	
	public function get_product_detail_by_slug($slug){
		//get all varoations data on edit  
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->join("tbl_product_attribute_relation","tbl_product_attribute_relation.product_id = tbl_product.product_id");
		$this->db->where("tbl_product.product_slug",$slug);
		$query = $this->db->get();
	  	//echo $this->db->last_query();die;
		$result = $query->result_array();
		return $result;
	}
	
	
	public function get_product_detail_by_id($id){
		//get all varoations data on edit  
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->join("tbl_product_attribute_relation","tbl_product_attribute_relation.product_id = tbl_product.product_id");
		$this->db->where("tbl_product.product_id",$id);
		$query = $this->db->get();
	  	//echo $this->db->last_query();die;
		$result = $query->result_array();
		return $result;
	}
	public function get_product_detail($id){
		//get all varoations data on edit  
		$this->db->select("*");
		$this->db->from("tbl_product");
		$this->db->join("tbl_product_attribute_relation","tbl_product_attribute_relation.product_id = tbl_product.product_id");
		$this->db->where("tbl_product.product_id",$id);
		$query = $this->db->get();
	  	//echo $this->db->last_query();die;
		$result = $query->row_array();
		return $result;
	}
	//function to get citires according to state id
	
	public function enable_disable_product($productid,$status)
	{
		$this->db->where("product_id",$productid);
		$array=array("product_status"=>$status);
		$this->db->update("tbl_product",$array);		
	}
	
	public function archive_product($id)
	{
		$this->db->select("*");
		$this->db->from("tbl_product_attribute_relation");
		$this->db->where("product_id",$id);
		$query = $this->db->get();
		
		$result = $query->result_array();

		foreach($result as $key=>$val)
		{
			$where = array("product_id"=>$val["product_id"]);
			$array = array("status"=>4);
			$this->db->where($where);
			$this->db->update("tbl_product_attribute_relation",$array);
		}
		$where=array("product_id"=>$id);
		$arr = array("product_status"=>4);
		$this->db->where($where);
		return $this->db->update("tbl_product",$arr);	
	}
	
	public function archive_product_property($row_id)
	{
		$where=array("id"=>$row_id);
		$this->db->where($where);
		$this->db->delete("tbl_product_attribute_relation");		
	}
	
	public function get_product_images_comma_id($id){
		$this->db->select("image_name");
		$this->db->from("tbl_product_images");
		$this->db->where(array("product_id"=>$id,"image_status" =>1));
		$this->db->where_in("id",$id);
		$query = $this->db->get();
		$result = $query->result_array();
		return $result;
	}
	
	public function get_product_images($id){
		$this->db->select("image_name");
		$this->db->from("tbl_product_images");
		$this->db->where(array("product_id"=>$id,"image_status" =>1,"isDefault <>" =>1));
		$query = $this->db->get();
		$result = $query->result_array();
		return $result;
	}
	public function get_product_display_images($id){
		$this->db->select("*");
		$this->db->from("tbl_product_images");
		$this->db->where(array("product_id"=>$id,"image_status" =>1,"isDefault" =>1));
		$query = $this->db->get();
		$result = $query->row_array();
		return $result['image_name'];
	}
	public function insert_product_image($productattributeimages)
	{
		//It will check Image is available in database if avalable then it will remove it first 
		 $this->db->insert("tbl_product_images",$productattributeimages);
	}
	
	public function delete_product_display_image($datarr)
	{
	     
		  $this->db->where(array("product_id"=>$datarr,"isDefault"=>'1'));
		 return  $this->db->delete("tbl_product_images");
	}
	public function delete_product_support_image($datarr)
	{
	     
		 $this->db->where(array("product_id"=>$datarr,"isDefault"=>'0'));
		 return $this->db->delete("tbl_product_images");
	}
	
	public function get_featured_product(){
		
		//$from = time();
	    $to =(time() - 30*24*3600);
		//echo date("y-m-d",$from);
		//echo date("y-m-d",$to);
		
		$this->db->select("*");
		$this->db->from("tbl_product");
		//$this->db->where(array("product_status"=>1,"product_created_time >=" =>$to,"product_created_time  <=" =>$from));
		$this->db->where(array("product_status"=>1,"product_created_time >=" =>$to));
		$this->db->order_by("product_id","RANDOM");
		$this->db->limit(4,0);
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$result = $query->result_array();
		return $result;
	}
	
	public function get_featured_product_more(){
		
		//$from = time();
	    $to =(time() - 30*24*3600);
		//echo date("y-m-d",$from);
		//echo date("y-m-d",$to);
		
		$this->db->select("*");
		$this->db->from("tbl_product");
		//$this->db->where(array("product_status"=>1,"product_created_time >=" =>$to,"product_created_time  <=" =>$from));
		$this->db->where(array("product_status"=>1,"product_created_time >=" =>$to));
		$this->db->order_by("product_id","desc");
		$this->db->limit(12,0);
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$result = $query->result_array();
		return $result;
	}
	
	/*************************************************************************************************************/
	
	
	
	public function changefeatureproduct($productid,$status)
	{
		$this->db->where("id",$productid);
		$array=array("is_featured"=>$status);
		return $this->db->update("tbl_product",$array);		
	}
	
	
	
	public function getProductSizes($search=array())
	{
		$productid=$search["productid"];
		$this->db->select("id,size_name");
		$this->db->from("ugk_product_sizes");
		$this->db->where("product_id",$productid);
		$query=$this->db->get();
		$resultset=$query->result_array();
		$sizearr=array();
		$i=0;
		if(isset($search["type"]) && $search["type"]=="json")
		{
			foreach($resultset as $key=>$val)	
			{
				$sizearr["id"][$i]=$val["id"];
				$sizearr["size_name"][$i]=$val["size_name"];
				$i++;	
			}			
			return json_encode($sizearr);
		}
		else if(isset($search["type"]) && $search["type"]=="array")
		{
			foreach($resultset as $key=>$val)	
			{
				$sizearr["id"][$i]=$val["id"];
				$sizearr["size_name"][$i]=$val["size_name"];
				$i++;	
			}		
			
			return $sizearr;
		}
		else
		{
			return $resultset;
		}	
		
	}
	
	/***************************************************Product functions end***************************************/
	
	
	/***************************************Attributes functions starts*/
	public function getAttributeData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_attributes');
		if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_attributes.attribute_name",trim($searcharray["search"]));	
		}
		$where=array("attribute_relation" =>0,"attribute_status <>"=>"4");
		$this->db->where($where);
		$this->db->order_by("attribute_id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
	//	echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function add_property($arr)
	{
		return $this->db->insert("tbl_attributes",$arr);	
	}

	public function edit_property($arr)
	{
		$this->db->where("attribute_id",$arr["attribute_id"]);
		return $this->db->update("tbl_attributes",$arr);	
	}

	public function archive_property($id)
	{
		$where=array("attribute_id"=>$id);
		$array=array("attribute_status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_attributes",$array);		
	}

	public function get_property_by_attribute($id){
		$this->db->select("*");
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation" =>$id,"attribute_status <>"=>"4");
		$this->db->where($where);
		$query = $this->db->get();
	//	echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	public function getIndividualProperty($id)
		{
			$this->db->select("*");	
			$this->db->from('tbl_attributes');
			$where=array("attribute_id"=>$id,"attribute_status <> "=>"4");
			$this->db->where($where);
			$query = $this->db->get();
			$resultset=$query->row_array();
			return $resultset;	
		}
		
	public function get_color(){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>1,"attribute_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function get_color_name(){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>1,"attribute_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	
	public function get_size(){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>2,"attribute_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function get_quantity($id){
		$this->db->select("*");	
		$this->db->from('tbl_product_attribute_relation');
		$where=array("product_id"=>$id,"status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
	//	echo $this->db->last_query();die;
		$resultset = $query->result_array();
		return $resultset;	
	}
	/********************************************Attribue functions ends***************************************************************888*/
	
	
	
	/*************************************************category barnd price starts*******************************/
	public function getPriceData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_category_brand_price');
		$where=array("price_status <>"=>"4");
		$this->db->where($where);
		$this->db->order_by("price_id asc");
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function add_edit_price($arr)
	{
		if($arr["price_id"]=="")
		{
			return $this->db->insert("tbl_category_brand_price",$arr);	
		}	
		else
		{
			$this->db->where("price_id",$arr["price_id"]);
			return $this->db->update("tbl_category_brand_price",$arr);	
		}
	}
	public function add_edit_sell_cloth($arr)
	{
		if($arr["id"]=="")
		{
			return $this->db->insert("tbl_request_cloth",$arr);	
		}	
		else
		{
			$this->db->where("id",$arr["id"]);
			return $this->db->update("tbl_category_brand_price",$arr);	
		}
	}
	
	
	
	public function getIndividualPrice($id)
	{
		$this->db->select("*");	
		$this->db->from('tbl_category_brand_price');
		$where=array("price_id"=>$id,"price_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;	
	}
	
	public function archive_price($id)
	{
		$where=array("price_id"=>$id);
		$array=array("price_status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_category_brand_price",$array);		
		
	}	
	public function enable_disable_price($id,$status)
	{
		$this->db->where("price_id",$id);
		$array=array("price_status"=>$status);
		$this->db->update("tbl_category_brand_price",$array);		
	}
	
	
	public function view_sell_cloth($id)
	{
		$this->db->select("*");	
		$this->db->from('tbl_request_cloth');
		$where=array("id" => $id,"status <> " => "4");
		$this->db->where($where);
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$resultset=$query->row_array();
		return $resultset;	
	}
	
	
	public function get_price_by_category_brand($cid=NULL,$bid=NULL)
	{
		$this->db->select("*");	
		$this->db->from('tbl_category_brand_price');
		$where=array("category_id" => $cid,"brand_id" => $bid,"price_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset = $query->row_array();
		
		$price_from = NULL;
		$price_to = NULL;
		
		if(!empty($resultset["price_from"]) && (!empty($resultset["price_to"]))){
			$arr["price_from"] = $resultset["price_from"];
			$arr["price_to"] = $resultset["price_to"];
		}
		else{
			$arr["price_from"] = '0.00';
			$arr["price_to"] = '0.00';
		}
		
		return json_encode($arr);
		//return "&#165;".$price_from."～ &#165;".$price_to;
	}
	/*************************************************category barnd price ends*******************************/
	/**************************************************brand functions starts*********************************/
	
	public function getBrandData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_brand');
		if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_brand.brand_name",trim($searcharray["search"]));	
		}
		$where=array("brand_status <>"=>"4");
		$this->db->where($where);
		$this->db->order_by("brand_id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
	//	echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	public function get_all_brands(){
		$this->db->select("*");
		$this->db->from('tbl_brand');
		$where=array("brand_status <> "=>4);
		$this->db->where($where);
		$this->db->order_by("brand_name ASC");
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;		
	}
	
	public function get_all_condition(){
		$this->db->select("*");
		$this->db->from('tbl_condition');
		$where=array("condition_status <> "=>4);
		$this->db->where($where);
		$this->db->order_by("condition_name ASC");
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;		
	}
	
	
	public function add_edit_brand($arr)
	{
		if($arr["brand_id"]=="")
		{
			return $this->db->insert("tbl_brand",$arr);	
		}	
		else
		{
			$this->db->where("brand_id",$arr["brand_id"]);
			return $this->db->update("tbl_brand",$arr);	
		}
	}
	
	public function getIndividualBrand($id)
	{
		$this->db->select("*");	
		$this->db->from('tbl_brand');
		$where=array("brand_id"=>$id,"brand_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;	
	}
	
	public function archive_brand($id)
	{
		$where=array("brand_id"=>$id);
		$array=array("brand_status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_brand",$array);		
		
		
		/*$this->db->select("product_id");
		$this->db->from("tbl_product_category");
		$this->db->where(array("category_id"=>$category_id));
		//$this->db->last_query();die;
		$products=$this->db->get();
		

		foreach($products->result_array() as $key=>$val)
		{
			$where=array("id"=>$val);
			$array=array("product_status"=>4);
			$this->db->where($where);
			$this->db->update("tbl_product",$array);
		}*/
	}	
	public function enable_disable_brand($id,$status)
	{
		$this->db->where("brand_id",$id);
		$array=array("brand_status"=>$status);
		$this->db->update("tbl_brand",$array);		
	}
	
	
	
	/********************************************************brand function ends***************************************************/
	
	
	
	/**************************************************Category functions starts*********************************/
	
	public function getCategoryData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_categories');
		if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_categories.category_name",$searcharray["search"]);	
		}
		$where=array("category_status <>"=>"4","parent_category"=>"0");
		$this->db->where($where);
		$this->db->order_by("id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
	//	echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function add_edit_category($categoryarray)
	{
		if($categoryarray["id"]=="")
		{
			return $this->db->insert("tbl_categories",$categoryarray);	
		}	
		else
		{
			$this->db->where("id",$categoryarray["id"]);
			return $this->db->update("tbl_categories",$categoryarray);	
		}
	}
	
	public function getIndividualCategory($categoryid)
	{
		$this->db->select("*");	
		$this->db->from('tbl_categories');
		$where=array("id"=>$categoryid,"category_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;	
	}
	
	public function archive_category($category_id)
	{
		$where=array("id"=>$category_id);
		$array=array("category_status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_categories",$array);		
		
		
		/*$this->db->select("product_id");
		$this->db->from("tbl_product_category");
		$this->db->where(array("category_id"=>$category_id));
		//$this->db->last_query();die;
		$products=$this->db->get();
		

		foreach($products->result_array() as $key=>$val)
		{
			$where=array("id"=>$val);
			$array=array("product_status"=>4);
			$this->db->where($where);
			$this->db->update("tbl_product",$array);
		}*/
	}	
	public function enable_disable_category($categoryid,$status)
	{
		$this->db->where("id",$categoryid);
		$array=array("category_status"=>$status);
		$this->db->update("tbl_categories",$array);		
	}
	
	
	function archive_sub_category($category_id)
	{
		$where=array("id"=>$category_id);
		$array=array("category_status"=>4);
		$this->db->where($where);
		$this->db->update("tbl_categories",$array);	
			
		/*$this->db->select("product_id");
		$this->db->from("tbl_product_category");
		$this->db->where(array("category_id"=>$category_id));
		$products=$this->db->get();
		foreach($products->result_array() as $key=>$val)
		{
			$where=array("id"=>$val);
			$array=array("product_status"=>4);
			$this->db->where($where);
			$this->db->update("tbl_product",$array);
		}*/
	}
	
	
	
	/********************************************************Category function ends***************************************************/
	
	/********************************************************Sub Category function starts*********************************************/
	
	public function getSubCategoryData($searcharray=array())
	{
		
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
			$this->db->select("*");
			$this->db->from('tbl_categories');		
			if(isset($searcharray["search"]) && $searcharray["search"]!="" && $searcharray["search"]!="search")
			{
				$this->db->like("tbl_categories.category_name",$searcharray["search"]);	
			}
			if(isset($searcharray["category"]) && $searcharray["category"]!="")
			{
				$where=array("parent_category"=>$searcharray["category"]);
				$this->db->where($where);
			}
			
			$where=array("category_status <>"=>"4","parent_category <>"=>"0");
			$this->db->where($where);
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
				{
					$this->db->limit($recordperpage,$startlimit);
				}
			}
			$query = $this->db->get();
			$resultset=$query->result_array();
			return $resultset;	
	}
	//get category name by id 
	public function getCategoryNameFromId($id="")
	{
		$this->db->select("category_name");
		$this->db->from('tbl_categories');
		$where=array("id"=>$id);
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset["category_name"];			
	}
	public function getIndividualSubCategory($categoryid)
	{
		$this->db->select("*");	
		$this->db->from('tbl_categories');
		$where=array("id"=>$categoryid,"parent_category <>" =>0,"category_status <> "=>"4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;	
	}
	public function add_edit_sub_category($subcategoryarr)
	{
		if($subcategoryarr["id"]=="")
		{
			return $this->db->insert("tbl_categories",$subcategoryarr);	
		}	
		else
		{
			$this->db->where("id",$subcategoryarr["id"]);
			return $this->db->update("tbl_categories",$subcategoryarr);	
		}	
	}
	//select all categories 
	public function get_all_category(){
		$this->db->select("*");
		$this->db->from('tbl_categories');
		$where=array("parent_category" =>0,"category_status <> "=>4);
		$this->db->where($where);
		$this->db->order_by("category_name ASC");
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;		
	}
	
	//select all categories 
	public function get_sub_category_name($id){
		$this->db->select("*");
		$this->db->from('tbl_categories');
		$where=array("id" => $id,"parent_category <>" =>0,"category_status <> "=>4);
		$this->db->where($where);
		$query = $this->db->get();
		//echo	$this->db->last_query();die;
		$resultset=$query->row_array();
		return $resultset;		
	}
	public function getSellData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_request_cloth');
		/*if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_request_cloth.brand_name",trim($searcharray["search"]));	
		}*/
		$where=array("status <>"=>"4");
		$this->db->where($where);
		$this->db->order_by("id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
		//  echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function enable_disable_sell_cloth($categoryid,$status)
	{
		
		$this->db->where("id",$categoryid);
		
		if($status==1){	
			$array=array("status"=>$status,"accepted_time" =>time());
		}
		else{
			$array=array("status"=>$status);
		}
		$this->db->update("tbl_request_cloth",$array);	
	//echo	$this->db->last_query();die;	
	}
	
	public function archive_sell_cloth($row_id)
	{
		$where=array("id"=>$row_id);
		$this->db->where($where);
		$array = array("status"=>4);
		$this->db->update("tbl_request_cloth",$array);		
	}
	/********************************************************Sub Category function ends*********************************************/
	
	/******************************************************Images function starts****************************************************/
	
	public function getProductImages($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		$searchdata=array("status"=>"product_status","product"=>"product_id","productype"=>"product_attribute_id");
		$this->db->select("*,ugk_product_images.id as image_id");
		$this->db->from("ugk_product_images");
		$this->db->join("tbl_product","ugk_product_images.product_id=tbl_product.id");
		$this->db->join("ugk_stores","tbl_product.user_uniq=ugk_stores.id");			
		if(isset($searcharray["search"]) && $searcharray["search"]!="" && $searcharray["search"]!="search")
		{
			//$this->db->like("ugk_stores.store_name",$searcharray["search"]);
			//$this->db->or_like("tbl_product.product_name",$searcharray["search"]);	
		}
		foreach($searcharray as $key=>$val)
		{
			if(isset($searcharray[$key]) && $searcharray[$key]!="")
			{
				if(array_key_exists($key,$searchdata))
				{
					$where=array($searchdata[$key]=>$val);
					$this->db->where($where);
				}
			}
		}	
		$this->db->where(array("tbl_product.product_status <>"=>4,"ugk_product_images.image_status <>"=>4,"ugk_stores.store_status <>"=>4));
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}		
		$result=$this->db->get();
		$this->db->last_query();
		return $result->result_array();
	}

	
	
	function archive_image($imageid)
	{
		$where=array("id"=>$imageid);
		$array=array("image_status"=>4);
		$this->db->where($where);
		$this->db->update("ugk_product_images",$array);		
	}
	
	public function enable_disable_image($imageid,$status)
	{
		$this->db->where("id",$imageid);
		$array=array("image_status"=>$status);
		$this->db->update("ugk_product_images",$array);		
	}
	
	public function get_default_image($productid)
	{
		$this->db->select("image_name");
		$this->db->from("tbl_product_images");
		$this->db->where(array("product_id"=>$productid,"isDefault"=>"1"));
		$query = $this->db->get();
		$rowcount = $query->num_rows();
		if($rowcount==0)
		{
			$this->db->select("image_name");
			$this->db->from("tbl_product_images");
			$this->db->where(array("product_id"=>$productid));
			$query = $this->db->get();	
			$defaultimage = $query->row_array();
			@$defaultimage=$defaultimage['image_name'];
		}	
		else
		{
			$defaultimage = $query->row_array();
			$defaultimage=$defaultimage['image_name'];	
		}
		
		return $defaultimage;
	}
	
public function get_default_image_slug($id)
	{
		$productid = $this->common->get_pdt_id_by_slug($id);
		$this->db->select("image_name");
		$this->db->from("tbl_product_images");
		$this->db->where(array("product_id"=>$productid,"isDefault"=>"1"));
		$query = $this->db->get();
		$rowcount = $query->num_rows();
		if($rowcount==0)
		{
			$this->db->select("image_name");
			$this->db->from("tbl_product_images");
			$this->db->where(array("product_id"=>$productid));
			$query = $this->db->get();	
			$defaultimage = $query->row_array();
			@$defaultimage=$defaultimage['image_name'];
		}	
		else
		{
			$defaultimage = $query->row_array();
			$defaultimage=$defaultimage['image_name'];	
		}
		
		return $defaultimage;
	}
	
	
	public function make_image_as_default($imageid)
	{
		$this->db->select("product_id");
		$this->db->from("ugk_product_images");
		$this->db->where(array("id"=>$imageid));
		$query=$this->db->get();
		$row=$query->row_array();
		$productid=$row["product_id"];
		$array=array("isDefault"=>"0");
		$where=array("product_id"=>$productid);
		$this->db->where($where);
		$this->db->update("ugk_product_images",$array);
		$array=array("isDefault"=>"1");
		$this->db->where("id",$imageid);
		$this->db->update("ugk_product_images",$array);
		return $productid;		
	}
	
	

	/******************************************************Images function ends****************************************************/
	
	

	
	public function enable_disable_attribute($id,$status)
	{
		$this->db->where("attribute_id",$id);
		$array=array("attribute_status"=>$status);
		$this->db->update("tbl_attributes",$array);	
		//	echo	$this->db->last_query();die;	
	}
	
	/******************************************************Products function ends****************************************************/
   	
	
	
	//get list of all brands 
	public function getBrandsList($value){
		
		 $sql= "select * from tbl_brand where brand_name like '".$value."%' and brand_status='1'";
		$query = $this->db->query($sql);
		$resultset=$query->result_array();
		return $resultset;		
	}
	
   public function get_color_by_name($name){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>1,"attribute_status <> "=>"4","attribute_name"=>$name);
		$this->db->where($where);
		$query = $this->db->get();
	//echo	$this->db->last_query();die;
		$resultset=$query->row_array();
		return $resultset;	
	}
	 public function get_color_name_byid($id){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>1,"attribute_status <> "=>"4","attribute_id"=>$id);
		$this->db->where($where);
		$query = $this->db->get();
	    //echo	$this->db->last_query();die;
		$resultset=$query->row_array();
		return $resultset["attribute_name"];	
	}
	
	 public function get_color_comma_id($id){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>1,"attribute_status <> "=>"4");
		$this->db->where($where);
		$this->db->where_in("attribute_id", $id); //pass array of 'id' from above query
		$query = $this->db->get();
	    //echo	$this->db->last_query();die;
		$resultset = $query->result_array();
		foreach($resultset as $k =>$v){
			$data[] =  $v["attribute_name"];
		}
		$res = implode(', ',$data);
		return $res;
	}
	
	
	 public function get_size_name_byid($id){
		
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>2,"attribute_status <> "=>"4","attribute_id"=>$id);
		$this->db->where($where);
		$query = $this->db->get();
	    //echo	$this->db->last_query();die;
		$resultset=$query->row_array();
		return $resultset["attribute_name"];	
	}
	 public function get_size_comma_id($id){
		
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>2,"attribute_status <> "=>"4");
		$this->db->where($where);
		$this->db->where_in("attribute_id", $id); //pass array of 'id' from above query
		$query = $this->db->get();
	   // echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		foreach($resultset as $k =>$v){
			$data[] =  $v["attribute_name"];
		}
		$res = implode(', ',$data);
		return $res;	
	}
	

	 public function get_size_by_name($name){
		$this->db->select("*");	
		$this->db->from('tbl_attributes');
		$where=array("attribute_relation"=>2,"attribute_status <> "=>"4","attribute_name"=>$name);
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;	
	}
		
	public function getFriendData($searcharray=array())
	{
		$recordperpage="";
		$startlimit="";
		if(!isset($searcharray["page"]) || $searcharray["page"]=="")
		{
			$searcharray["page"]=0;	
		}
	    if(!isset($searcharray["countdata"]))
		{	
			if(isset($searcharray["per_page"]) && $searcharray["per_page"]!="")
			{
				$recordperpage=$searcharray["per_page"];	
			}
			else
			{
				$recordperpage=1;
			}
			if(isset($searcharray["page"]) && $searcharray["page"]!="")
			{
				$startlimit=$searcharray["page"];	
			}
			else
			{
				$startlimit=0;
			}
		}
		
		
		$this->db->select("*");
		$this->db->from('tbl_invite_friend');
		/*if(isset($searcharray["search"]) && $searcharray["search"]!="")
		{
			$this->db->like("tbl_categories.category_name",$searcharray["search"]);	
		}*/
		$where=array("invite_friend_status <>"=>"4");
		$this->db->where($where);
		$this->db->order_by("id desc");
		/*if(isset($searcharray["type"]) && $searcharray["type"]=="activated")
		{
			$where=array("status"=>"1");
		}*/
				
		if(isset($searcharray["page"]) && $searcharray["page"]!="")
		{
			if($recordperpage!="" && ($startlimit!="" || $startlimit==0))
			{
				$this->db->limit($recordperpage,$startlimit);
			}
		}
		$query = $this->db->get();
	//	echo	$this->db->last_query();die;
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	public function add_edit_invite_friend($categoryarray)
	{
		if($categoryarray["id"]=="")
		{
			return $this->db->insert("tbl_invite_friend",$categoryarray);	
		}	
		else
		{
			$this->db->where("id",$categoryarray["id"]);
			return $this->db->update("tbl_invite_friend",$categoryarray);	
		}
	}
	
	public function get_all_friend(){
		$this->db->select("*");	
		$this->db->from('tbl_invite_friend');
		$where = array("invite_friend_status <> " => "4");
		$this->db->where($where);
		$this->db->order_by('id asc');
		$query = $this->db->get();
		$resultset=$query->result_array();
		return $resultset;	
	}
	
	
	public function getIndividualFriend($categoryid)
	{
		$this->db->select("*");	
		$this->db->from('tbl_invite_friend');
		$where=array("id" => $categoryid,"invite_friend_status <> " => "4");
		$this->db->where($where);
		$query = $this->db->get();
		$resultset=$query->row_array();
		return $resultset;	
	}
	
	public function archive_invite_friend($category_id)
	{
		$where = array("id" => $category_id);
		$array = array("invite_friend_status" => 4);
		$this->db->where($where);
		$this->db->update("tbl_invite_friend",$array);		
		
	}	
	public function enable_disable_invite_friend($categoryid,$status)
	{
		$this->db->where("id",$categoryid);
		$array=array("category_status"=>$status);
		$this->db->update("tbl_categories",$array);		
	}
}
?>