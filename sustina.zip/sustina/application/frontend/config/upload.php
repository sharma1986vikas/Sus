<?php 
$config['upload_path'] = './productimages/';
$config['allowed_types'] = '*';
?>