<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pages extends CI_Controller {


	public function __construct()
	{
		parent::__construct();
		$this->load->model('email_model');
		$this->load->model("page_model");
		$this->load->model("blog_model");
	}
	
	public function _remap()
	{
		$pagedata = $this->uri->segment(2);
		if($pagedata == 'about_us'){
			$this->about_us($pagedata);	
		}
		else if($pagedata == 'contact'){//load contact page
			$this->contact($pagedata);	
		}
		else if($pagedata == 'contact_request'){//send email when form posted
			$this->contact_request();
		}
		else if($pagedata == 'email_sent'){
			$this->email_sent($pagedata);	
		}
		
		else if($pagedata == 'careers'){
			$this->careers($pagedata);	
		}
		else if($pagedata == 'blog'){
			$this->blog($pagedata);	
		}
		
		else if($pagedata == 'terms'){
			$this->terms($pagedata);
		}
		/*
		else if($pagedata == 'submit_application'){
			$this->submit_application($pagedata);
				
		}
		else if($pagedata == 'upload_attchement'){
			$this->upload_attchement($pagedata);
				
		}
		else if($pagedata == 'unlink_attachment'){
			$this->unlink_attachment($pagedata);
				
		}*/
		
	}

	public function about_us($pagedata){
		$data['item'] ='About Us';
		$data['active'] = $pagedata;
		$data['master_title'] = "About Us";
		$data['master_body'] = 'about_us';
		$data['resultset'] = $this->page_model->get_contact_data($pagedata);
		$this->load->theme('mainlayout',$data);
	}
	
	
	public function contact($pagedata){
		$data['item'] = 'Contact';
		$data['active'] = $pagedata;
		$data["resultset"] = $this->page_model->get_contact_data($pagedata);
		//$data["contact_request"] = 'contact_request';//function call on form submit used in view as $contact_request
		$data["userdata"]=$this->session->userdata("tempdata");
		//$data["leftbar"] = "leftbar/email_sent";
	    $data['master_title'] = 'Contact Us';
		$data['master_body'] = 'contact_us';
		$this->load->theme("mainlayout",$data);	
	}
	
	public function blog($pagedata){
		$data['item'] = 'Blog';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->get_blog_data($pagedata);
		$data['master_title'] = 'Blog';
		$data['master_body'] = 'blog';
		//debug($data);die;
		$this->load->theme("mainlayout",$data);	
	}
	
	/*public function faq($pagedata){
		$data['item'] = 'FAQ';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getFaqData($pagedata);
		$data['master_title'] = 'FAQ';
		$data['master_body'] = 'faq';
		$this->load->theme("mainlayout",$data);	
	}
	public function sell($pagedata){
		$data['count'] = count($this->cart->contents());
		$data['item'] = 'Sell';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getPageData($pagedata);
		$data['master_title'] = 'Sell';
		$data['master_body'] = 'sell';
		$this->load->theme("mainlayout_contant",$data);	
	}
	*/
	
	
	public function careers($pagedata){
		$data['count'] = count($this->cart->contents());
		$data['item'] = 'Career';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getPageData($pagedata);
		$data['master_title'] = 'Careers';
		$data['master_body'] = 'careers';
		$this->load->theme("mainlayout_contant",$data);	
	}
	public function email_sent(){
		$data['item'] = 'Email sent';
		$data['active'] = $pagedata;
		$data['master_title'] = "Email sent";
		$data['master_body'] = 'email_sent';
		//print_r($data);
		$this->load->theme('mainlayout',$data);
	}
	
	/*public function returns($pagedata){
		
		$data['item'] = 'Returns';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getPageData($pagedata);
		$data['master_title'] = 'Returns';
		$data['master_body'] = 'Returns';
		$this->load->theme("mainlayout_contant",$data);	
	}
	public function press($pagedata){
		$data['count'] = count($this->cart->contents());
		$data['item'] = 'Press';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getPageData($pagedata);
		$data['master_title'] = 'Press';
		$data['master_body'] = 'press';
		$this->load->theme("mainlayout_contant",$data);	
	}
public function support($pagedata){
		$data['item'] = 'Support';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getPageData($pagedata);
		$data['master_title'] = 'Support';
		$data['master_body'] = 'Support';
		$this->load->theme("mainlayout_contant",$data);	
	}
public function terms($pagedata){
		$data['item'] = 'Terms And Conditions';
		$data['active'] = $pagedata;
		$data['content'] = $this->page_model->getPageData($pagedata);
		$data['master_title'] = 'Terms and Conditions';
		$data['master_body'] = 'terms';
		$this->load->theme("mainlayout_contant",$data);	
	}
*/
	public function contact_request()
	{
		$arr["to"] = $this->config->item("adminemail");
		$arr["name"]=$this->input->post("name");
		$arr["email"]=$this->input->post("email");
		$arr["subject"]=$this->input->post("subject");
		$arr["message"]=$this->input->post("message");	
		$data["userdata"] = $this->session->set_userdata("tempdata",$arr);
		if($this->validations->validate_contact_request($arr))
		{
			$message = '<table width="100%" border="0" bgcolor="#E0E0E0" cellspacing="1" cellpadding="6" style="border:solid 4px #0076BE;">';
 			$message .= '<tr><td colspan="2" style="font-size:24px; font-weight:bold; color:#002a76;">User Has Sent You a Mail</td></tr>';
			$message .= '<tr><td bgcolor="#fbf9f9" width="100"><strong>Parson Name</strong></td><td width="150" bgcolor="#fbf9f9">'.$arr['name'].'</td></tr>';
			$message .= '<tr><td bgcolor="#fbf9f9" width="100"><strong>Email Id</strong></td><td width="150" bgcolor="#fbf9f9">'.$arr['email'].'</td></tr>';
 			$message .= '<tr><td bgcolor="#fbf9f9" width="100"><strong>Message</strong></td><td width="150" bgcolor="#fbf9f9">'.$arr['message'].'</td></tr></table>';
			
			$arr["message"] = $message;
			if($this->email_model->sendIndividualEmail($arr)==1){ 
				$err=1;
				$this->session->set_flashdata("errormsg","There was error in sending email.");
			}
			else{
				$err=0;
				//$this->session->set_flashdata("successmsg","Your request has been successfuly submitted Thanks!");
				$this->session->unset_userdata('tempdata');
				redirect(base_url().$this->router->class."/email_sent");
			}
		}
		redirect(base_url()."pages/contact");
	}
	
	 public function unlink_attachment()
	 {
		  $image_name=$this->uri->segment(3); 
		  $path = "productimages/".$image_name;
		  
		  chmod("$path",0777);  // set permission to the file.
		  unlink('attachments/'.$image_name);
		  return "success"; die;
     }
	
	public function upload_attchement()
	{
	   //  debug($_FILES['uploadfile']['name']);die;
	     $size = $_FILES['uploadfile']['size'];
		
	     if($size < (1024*1024*5))
		 {
			
		 $type=explode('/',$_FILES['uploadfile']['type']);
		 $ext=$type['1'];
		 $image_name= "st_".time()."_".$_FILES['uploadfile']['name']; 
         $path = "attachments/".$image_name;
		 chmod("$path",0777);  // set permission to the file.
		 if(copy($_FILES['uploadfile']['tmp_name'], $path))//  upload the file to the server
		 {
			 echo "success|::|".$image_name;	
		 }
		 else
		 {
			echo "error"; die;
		 }
		 }
		  else
		 {
		    echo "error"; die;
		 }	 
		
	}
	
	public function submit_application()
	{
		
		 
		$arr["email"]=$this->input->post("email");
		$arr["name"]=$this->input->post("name");
		$arr["message"]=$this->input->post("message");
		$arr["position"]=$this->input->post("position");
		$arr["interest"]=$this->input->post("interest");
		$arr["information"]=$this->input->post("message");
		$arr["subject"]="Application from user for carrer in social tyer";
		if($this->input->post("attachment")!=""){
		$arr["attachment"]=$this->input->post("attachment");
		//$arr['path'] = base_url().'attachments/'.$arr["attachment"];
		//$arr["path"]= base_url().'attachments/'.$arr["attachment"];
		}
		      
			    $arr["message"] = "<p>Hi,</p>";
				$arr["message"].="<p>Here is my personal information</p> ";
				$arr["message"].="<p>Name : ".$arr["name"]."</p> ";
				$arr["message"].="<p>Email : ".$arr["email"]."</p> ";
				foreach($arr["position"] as $data)
				{
					$position.= $data.",";
				}
					$position = substr($position,0,strlen($position)-1);
			   $arr["message"].="<p>position : ".$position."</p> ";
	      	   foreach($arr["interest"] as $datas)
				{
					$interest.= $datas.",";
				}
					$interest = substr($interest,0,strlen($interest)-1);
			
			   $arr["message"].="<p>position : ".$interest."</p> ";
			 
			   $arr["message"].="<p>Message: ".$arr["information"]."</p> ";
			   
			   
				
		    $this->session->set_flashdata("tempdata",$arr);
		
			$arr["to"]='alwani1990@gmail.com';  ////
			
			//debug($arr);die;
			if($this->email_model->send_contact_email($arr))
			{
				unlink('attachments/'.$arr["attachment"]);
				echo "success";die;
			}	
			else
			{
				echo "error";die;
			}
			
		
		
	}
	
	
	
	
}
