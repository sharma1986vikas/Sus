<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class products extends CI_Controller {

	public function __construct(){
		
		parent::__construct();
		//$this->load->model("page_model");
		$this->load->model('user_model');
		$this->load->model('email_model');
		$this->load->model('products_model');
	}
	
	//request a cloth
    public function brand_purchase(){
		$this->common->is_logged_in();
		$data["featured"] = $this->products_model->get_featured_product();
		
	    $data["item"]="sustaina";
		$data["master_title"] = $this->config->item("sitename")." -brand-purchase"; 
		
		$data["master_body"]="brand_purchase";
		$this->load->theme('mainlayout',$data);
	}
	
	public function recommended_products(){
		$this->common->is_logged_in();
		$data["featured_more"] = $this->products_model->get_featured_product_more();
		//debug($data["featured_more"]);die;
	    $data["item"]="Recommended New arrivals";
		$data["master_title"] = $this->config->item("sitename")." - recommended products"; 
		$data["selldata"] = $this->session->flashdata("tempdata"); 
		$data["master_body"]="recommended_products";
		$this->load->theme('mainlayout',$data);
	}
	
	public function product_detail(){
		$this->common->is_logged_in();
		$id = $this->uri->segment(3);
		$data["product_data"] = $this->products_model->get_product_detail_slug($id);
		$data["default_image"] = $this->products_model->get_default_image_slug($id);
	    $data["products_slug_data"] = $this->products_model->get_product_detail_by_slug($id);
		//debug($data["product_detail"]);die;
	    $data["item"]="Recommended New arrivals";
		$data["master_title"] = $this->config->item("sitename")." - product detail"; 
		$data["product_detail"] = $this->session->flashdata("tempdata"); 
		$data["master_body"]="product_detail";
		$this->load->theme('mainlayout',$data);
	}
	
	//// get all Categories
	public function category(){
		$this->common->is_logged_in();
		//$data["resultset"] = $this->products_model->getCategoryData();
		$data["item"]="Categories";
		$data["master_title"] = $this->config->item("sitename")." - categories"; 
		$data["master_body"]="categories";
		
		
		
		/*--------------------------Paging code starts---------------------------------------------------*/
		$page=isset($_GET["per_page"]) ? $_GET["per_page"] : ""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }
		else{
            if(!is_numeric($page)){
            	redirect(BASEURL.'404');
            }
			else{
            	$page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/category/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getCategoryData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getCategoryData($searcharray);

		$this->load->theme('mainlayout',$data);
	}
	
	//// get all sub category
	public function sub_category(){
		$this->common->is_logged_in();
	    $data["item"]="Sub Categories";
		$data["master_title"] = $this->config->item("sitename")." -Sub categories"; 
		$data["master_body"]="sub_categories";
			/*--------------------------Paging code starts---------------------------------------------------*/
		$page=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:""; //$this->input->get("page");
		
		if($page == '')
        {
            $page = '0';
        }else{
            if(!is_numeric($page)){
            	redirect(BASEURL.'404');
            }
			else{
            	$page = $page;
            }
        }
		
		$config["per_page"] = $this->config->item("perpageitem"); 
		$config['base_url']=base_url().$this->router->class."/sub_category/?".$this->common->removeUrl("per_page",$_SERVER["QUERY_STRING"]);
		$countdata=array();
		$countdata=$_GET;
		$countdata["countdata"]="yes";	
		
		$config['total_rows']=count($this->products_model->getSubCategoryData($countdata));   
		$config["uri_segment"]=(isset($_GET["per_page"]) && $_GET["per_page"]!="")?$_GET["per_page"]:"0";
		$this->pagination->initialize($config);
		/*--------------------------Paging code ends---------------------------------------------------*/
		$searcharray=array();
		$searcharray=$_GET;
		$searcharray["per_page"]=$config["per_page"];
		$searcharray["page"]=$config["uri_segment"];
		$data["resultset"]=$this->products_model->getSubCategoryData($searcharray);
		$this->load->theme('mainlayout',$data);
	}
	
	//// get all brands
	public function brands(){
		$this->common->is_logged_in();
		$data["item"]="Brands";
		$data["master_title"] = $this->config->item("sitename")." - brands"; 
		$data["master_body"]="brands";
		$this->load->theme('mainlayout',$data);
	}
	
	//// get all brands
	public function pickups(){
		$this->common->is_logged_in();
		$data["item"]="Pick Brands";
		$data["master_title"] = $this->config->item("sitename")." - pickup brands"; 
		
		$data["master_body"]="pickups";
		$this->load->theme('mainlayout',$data);
	}
	
	//// get all colors
	public function colors(){
		$this->common->is_logged_in();
		$data["item"]="Colors";
		$data["master_title"] = $this->config->item("sitename")." - Colors"; 
		
		$data["master_body"]="colors";
		$this->load->theme('mainlayout',$data);
	}
	
	//// get all colors
	public function sizes(){
		$this->common->is_logged_in();
		$data["item"]="Sizes";
		$data["master_title"] = $this->config->item("sitename")." - Sizes"; 
		$data["master_body"]="sizes";
		$this->load->theme('mainlayout',$data);
	}
	
    //request a clothsearch by min price
	public function min_price(){
		$this->common->is_logged_in();
	    $data["item"]="Minimum Price";
		$data["master_title"] = $this->config->item("sitename")." -Minimum Price"; 
	    $data["master_body"]="price";
		$this->load->theme('mainlayout',$data);
	}
	//request a clothsearch by min price
	public function max_price(){
		$this->common->is_logged_in();
	    $data["item"]="Maximum Price";
		$data["master_title"] = $this->config->item("sitename")." -Maximum Price"; 
	    $data["master_body"]="price";
		$this->load->theme('mainlayout',$data);
	}
	
	
}
