<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>search/"> Menu</a>
  <h1>Brands purchase </h1>
</div>

<!--/Main content-->
<div class="container">
  <div class="coupon_main margin_t">
    <?php
	$brands=array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
			        foreach($brands as $key=>$val){
                    	$resultset=$this->products_model->getBrandsList($val) ;?>
    <div class="brands_title">
      <h1><?php echo $val;?></h1>
    </div>
    <?php  
					   $count= count($resultset);
					   if($count > 0){
					   $i=1; 
					   foreach($resultset as $k=>$v){
                       if($count==$i){$class='border_b';}else{$class='';}
                       ?>
    <a href="<?php echo base_url();?>search/brands_search/<?php echo $v['brand_name'];?>">
    <div class="coupon_c <?php echo $class;?>">
      <div class="coupon_price <?php echo $class;?>"> <?php echo ucfirst($v['brand_name']);?> </div>
    </div>
    </a>
    <?php $i++; } }else {?>
    <a href="Javascript:void(0);">
    <div class="coupon_c border_b">
      <div class="coupon_price" style="color:#F00;"> No Brand Found </div>
    </div>
    </a>
    <?php  } } ?>
  </div>
</div>

<!--/Main content--> 