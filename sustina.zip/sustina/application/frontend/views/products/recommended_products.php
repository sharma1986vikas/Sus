<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 class="margin_r"><?php echo $item;?></h1>
  <a href="" class="header_cart margin_r"><img src="<?php echo base_url();?>images/mypage_edit.png" /></a> </div>

<!------------------main-------------------------->

<div class="main_container">
<div class="middle-container"> <a href="<?php echo base_url();?><?php echo $this->router->class;?>/brand_purchase">
  <div class="blouse-top-search-box">Search</div>
  </a>
  <div class="sbp-style-img-container border-none">
    <?php 
	if(count($featured_more) > 0){
	$i=0;foreach($featured_more as $key =>$val){
		$default_image = $this->products_model->get_default_image($val["product_id"]);
	    $is_fav_product =  $this->products_model->is_fav_product($val["product_id"]);
	?>
    <?php if($i%2==0){?>
    <div class="sbp-style-img-container1">
      <div class="sbp-style-img-container1-left"> <a href="<?php echo base_url();?><?php echo $this->router->class;?>/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>"width="127" height="167" /></a>
        <div class="sbp-hrt-container">
          <div class="sbp-hrt-container-left">
          <?php if($is_fav_product == true){?>
                <a  href="javascript:void(0);">
                <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
                <?php }else{?>
                 <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);">
                <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
                <?php }?>
          </div>
          <div class="sbp-hrt-container-right">
            <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
              $<?php echo $val["price"];?></div>
          </div>
        </div>
      </div>
      
      <?php }else{?>
      <div class="sbp-style-img-container1-right"> <a href="<?php echo base_url();?><?php echo $this->router->class;?>/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167"/></a>
        <div class="sbp-hrt-container">
          <div class="sbp-hrt-container-left">
          <?php if($is_fav_product == true){?>
                <a  href="javascript:void(0);">
                <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
                <?php }else{?>
                 <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);">
                <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
                <?php }?>
          </div>
          <div class="sbp-hrt-container-right">
            <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
              $<?php echo $val["price"];?></div>
          </div>
        </div>
      </div>
      <?php }?>
      <?php $i++;}}else{?>
       <div  style="color:#F00;"> No Product Found </div>
      <?php }?>
    </div>
    <a href="blouse-search2.html">
    <div class="blouse-nxt-search1">Next</div>
    </a> </div>
</div>
