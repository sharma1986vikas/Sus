<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>search/"> Menu</a>
  <h1>Brands </h1>
</div>
<div class="container">
  <div class="coupon_main margin_t"> <a href="<?php echo base_url();?>search/search_result">
    <div class="coupon_c border_b">
      <div class="coupon_price"> ALL </div>
    </div>
    </a> </div>
  <div class="brands_main">
    <?php
	$brands=array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
			        foreach($brands as $key=>$val){?>
    <a class="brands_btn" href="<?php echo base_url();?>search/brand_search/<?php echo $val;?>"><?php echo $val;?></a>
    <?php }?>
    <!--  <a class="brands_btn" href="<?php echo base_url();?>search/brand_search/0-9">0-9</a>
                        <a class="brands_btn" href="<?php echo base_url();?>search/brand_search/other">other</a>--> 
  </div>
</div>

<!--/Main content-->