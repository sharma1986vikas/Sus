<div class="header-container1">
  <div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
    <h1>sustaina</h1>
  </div>
</div>

<!------------------main-------------------------->
<div class="main_container">
<div class="sbp-top-container sbp-white-bg margin_t">
  <div class="sbp-top-container-left">
    <div class="txt-sbp-top-container">Brand purchase in old clothes<br />
      limited time!<br />
      10% up now!</div>
  </div>
  <div class="sbp-top-container-right"> <img src="<?php echo base_url();?>images/sbp-top-img.jpg" /> </div>
</div>
<div class="middle-container">
  <div class="sbp-style-container sbp-white-bg"> <a href="">
    <div class="txt-sbp-style">Pick up Style</div>
    </a>
    <div class="sbp-style-img-container">
      <div class="sbp-style-img-container1">
        <div class="sbp-style-img-container1-left"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img1.jpg" /></a></div>
        <div class="sbp-style-img-container1-right"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img2.jpg" /></a></div>
      </div>
      <div class="sbp-style-img-container2">
        <div class="sbp-style-img-container2-left">
          <div class="sbp-style-img-container2-left-L"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img3.jpg" /></a></div>
          <div class="sbp-style-img-container2-left-R"><a href=""><img src="<?php echo base_url();?>images/pickstyle-img4.jpg" /></a></div>
        </div>
        <div class="sbp-style-img-container2-right"><img src="<?php echo base_url();?>images/pickstyle-img5.jpg" /></div>
      </div>
    </div>
    <a href="">
    <div class="txt-sbp-style-more">More</div>
    </a> </div>
  <div class="sbp-style-container sbp-white-bg"> <a href="">
    <div class="txt-sbp-style">Recommended New arrivals</div>
    </a>
    <div class="sbp-style-img-container">
      <?php if(count($featured) > 0){
	  		$i=0;foreach($featured as $key=>$val){
			$default_image = $this->products_model->get_default_image($val["product_id"]);
			$is_fav_product =  $this->products_model->is_fav_product($val["product_id"]);
	  ?>
      <?php if($i%2==0){$class='left';?>
      <div class="sbp-style-img-container1">
        <div class="sbp-style-img-container1-<?php echo $class;?>"> <a href="<?php echo base_url();?>products/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167" /></a>
          <div class="sbp-hrt-container">
            <?php if($is_fav_product == true){?>
            <div class="sbp-hrt-container-left fav"> <a href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a>
              <?php }else{?>
              <div id="fav_<?php echo $val["product_id"];?>" class="sbp-hrt-container-left non_fav"> <a onclick="return add_favorite('<?php echo $val["product_id"];?>');" href="javascript:void(0);"> <img src="<?php echo base_url();?>images/sbp-hrt-img.jpg" /></a>
                <?php }?>
              </div>
              <div class="sbp-hrt-container-right">
                <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
                  $<?php echo $val["price"];?></div>
              </div>
            </div>
          </div>
          <?php }else{$class='right';?>
          <div class="sbp-style-img-container1-<?php echo $class;?>"> <a href="<?php echo base_url();?>products/product_detail/<?php echo $val["product_slug"];?>"><img src="<?php if($default_image <>""){ echo $this->config->item("productimageurl").$default_image;}else{echo $this->config->item("default_productimage");}?>" width="127" height="167"/></a>
            <div class="sbp-hrt-container">
              <div class="sbp-hrt-container-left"><a href="javascript:void(0);"><img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg" /></a></div>
              <div class="sbp-hrt-container-right">
                <div class="txt-sbp-hrt-container-right"><?php echo $val["title"];?><br />
                  $<?php echo $val["price"];?></div>
              </div>
            </div>
          </div>
        </div>
        <?php }?>
        <?php $i++;}}?>
      </div>
     <div style="color:red">No product found</div>
      <?php if(count($featured) > 0){?>
      <a href="<?php echo base_url();?><?php echo $this->router->class;?>/recommended_products/">
      <div class="txt-sbp-style-more">More</div>
      </a> </div>
	  <?php }?>
    <div class="sbp-style-container sbp-white-bg"> <a href="#">
      <div class="txt-sbp-style">New Video</div>
      </a>
      <div class="sbp-video-container">
        <video width="100%" controls>
          <source src="<?php echo base_url();?>images/mov_bbb.mp4" type="video/mp4">
          <source src="<?php echo base_url();?>images/mov_bbb.ogg" type="video/ogg">
          Your browser does not support the video tag. </video>
      </div>
      <a href="#">
      <div class="txt-sbp-style-more">More</div>
      </a> </div>
  </div>
</div>
