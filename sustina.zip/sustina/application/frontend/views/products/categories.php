<!--Main content-->
<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Category </h1>
</div>
<div class="container">
  <div class="coupon_main margin_t">
    <?php 
	   $count = count($resultset);
	   if($count >0){
	   $i=1;
	   foreach($resultset as $key=>$val)
	   {
		if($count == $i){$class='border_b';}else{$class='fewe';}
	?>
    <a href="<?php echo base_url();?>search/category_search/<?php echo $val['slug'];?>">
    <div class="coupon_c <?php echo $class;?>">
      <div class="coupon_price"> <?php echo ucfirst($val['category_name']);?> </div>
    </div>
    </a>
    <?php $i++;}}else{?>
      <div  style="color:#F00;"> No Category Found </div>
    <?php }?>
  </div>
</div>
<?php  echo $this->pagination->create_links();?>
<!--/Main content-->