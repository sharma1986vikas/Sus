
<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 ><?php echo $item;?></h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="txt-confirmation"> Thank you for your request.<br />
        We will send you send bag. <br />
        It takes about three days to one week 
        usually. </div>
      <a href="<?php echo base_url();?>home">
      <button type="button" class="email-signup_btn" name="facebook">Home</button>
      </a> </div>
  </div>
</div>
