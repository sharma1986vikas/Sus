<div class="header">
  <h1 class="margin_r"><?php echo $item;?></h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="email-textbox-container">
        <form name="add" id="add" method="post" action="<?php echo base_url();?><?php echo $this->router->class;?>/add_user_to_database">
          <input class="email-textbox" style="border-bottom:none;" type="text" name="email" value="<?php echo $userdata["email"];?>" placeholder="E-mail"  />
          <input class="email-textbox"  type="password" name="password" value="<?php echo $email_signin["password"];?>" placeholder="Password"  />
          <a class="txt-password-forget" href="<?php echo base_url();?>users/forgot_password">Password Forgot</a>
          <input type="submit" class="email-signup_btn" name="facebook" value="Login">
        </form>
      </div>
    </div>
  </div>
</div>
