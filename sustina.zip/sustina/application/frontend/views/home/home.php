<div class="wrapper"> 
  
  <!--Main content-->
  <div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
    <h1 class="home_logo"><?php echo $item;?></h1>
  </div>
  <div class="home_main_content">
    <div class="container">
      <div class="title"> Women's Fashion<br>
        Brand cloths store in limited release<br>
        70% -90% OFFSell &amp; Buy </div>
     <form id="form" method="post" action="<?php echo base_url();?>home/add_referal_code">
      <div class="sign_up_main">
        <div class="sign_up">
            <div class="txt-confirmation" style="top: 258px;left: 61px; position:absolute; float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>

          <input type="text" id="referal_code" placeholder="Invitation Code" name="referal_code" class="text_field">
        </div>
        <a href="javascript:void(0);" class="sign_up_btn" onclick="return submit_form_home();">Sign Up</a>
        <!--<button type="submit" class="sign_up_btn" >Sign Up</button>--> </div>
        </form>
      <a href="<?php echo base_url();?>home/signin" class="login_btn"> Login</a>
      <div class="index_video"> <a href="<?php echo base_url();?>home/video">
        <video width="100%" controls>
          <source src="<?php echo base_url();?>images/mov_bbb.mp4" type="video/mp4">
          <source src="<?php echo base_url();?>images/mov_bbb.ogg" type="video/ogg">
          Your browser does not support the video tag. </video>
        </a> </div>
    </div>
  </div>
  
  <!--/Main content--> 
  
</div>
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
