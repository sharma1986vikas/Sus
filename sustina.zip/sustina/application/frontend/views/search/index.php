<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Search </h1>
</div>
<div class="container">
  <div class="coupon_main">
    <div class="coupon_field">
      <form id="search" action="<?php echo base_url();?>search/search_result" method="post">
        <input class="coupon_textfield" type="text" placeholder="Enter Keyword here" id="keyword" name="keyword">
      </form>
      <a class="coupon_btn" href="javascript:void(0);" onclick="submit_form();">Search</a> </div>
    <a href="<?php echo base_url();?>products/category">
    <div class="coupon_c">
      <div class="coupon_price"> Category </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/brands">
    <div class="coupon_c">
      <div class="coupon_price"> Brand </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/pickups">
    <div class="coupon_c">
      <div class="coupon_price"> Pickup Brand </div>
    </div>
    </a> <a href="<?php echo base_url();?>search/refine_search">
    <div class="coupon_c border_b">
      <div class="coupon_price"> Refine Search </div>
    </div>
    </a> </div>
</div>

<!--/Main content--> 
<script  type="text/javascript" src="<?php echo base_url();?>js/jsfunctions.js"></script>
