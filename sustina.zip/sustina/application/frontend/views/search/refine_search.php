<!--Main content-->

<div class="header"> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Search </h1>
</div>
<div class="container">
  <div class="coupon_main margin_t"> <a href="<?php echo base_url();?>products/category">
    <div class="coupon_c">
      <div class="coupon_price"> Category </div>
      <div class="coupon_date"> select </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/sub_category">
    <div class="coupon_c">
      <div class="coupon_price"> Sub Category </div>
      <div class="coupon_date"> Select </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/brands">
    <div class="coupon_c">
      <div class="coupon_price"> Brands </div>
      <div class="coupon_date"> Select </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/colors">
    <div class="coupon_c">
      <div class="coupon_price"> Color </div>
      <div class="coupon_date"> Select </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/sizes">
    <div class="coupon_c">
      <div class="coupon_price"> Size </div>
      <div class="coupon_date"> Select </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/max_price">
    <div class="coupon_c">
      <div class="coupon_price"> Max Price </div>
      <div class="coupon_date"> Input </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/min_price">
    <div class="coupon_c">
      <div class="coupon_price"> Minimum Price </div>
      <div class="coupon_date"> Input </div>
    </div>
    </a> <a href="<?php echo base_url();?>products/conditions">
    <div class="coupon_c">
      <div class="coupon_price"> Condition </div>
      <div class="coupon_date"> Select </div>
    </div>
    </a> <a href="r_search.html">
    <div class="coupon_c border_b">
      <div class="coupon_price"> Price type </div>
      <div class="coupon_date"> Select </div>
    </div>
    </a> </div>
</div>
