
<div class="header">
  <h1 class="margin_r"><?php echo $item;?></h1>
</div>
<div class="container">
<div class="main_container">
  <div class="middle-container">
    <div class="txt-confirmation" style=" position:absolute; top: 38px;float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>
    
    <form method="post" action="<?php echo base_url();?>users/forgot_password_email">
    <div class="email-textbox-container">
      <input class="email-textbox" type="text" name="email" value="<?php echo $forgot["email"];?>"  placeholder="E-mail"  />
      <button type="submit" class="email-signup_btn" name="facebook">
     Reset password
      </button>
    </div>
    </form>
  </div>
</div>
