  <div class="header">
    <h1 class="margin_r"><?php echo $item;?></h1>
    </div>
    <div class="container">
    <div class="main_container">
        <div class="middle-container">
            <div class="txt-confirmation">
                We've send you an email of the password reset to the email address has been your registration.<br /><br />
                Thankyou to set a new password.
            </div>
<!--            <button type="button" class="email-signup_btn" name="facebook"><a href="">Reset password</a></button>
-->        </div>
    </div>    
</div>