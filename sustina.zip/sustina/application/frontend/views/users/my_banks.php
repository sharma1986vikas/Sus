<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a> <a href="" class="header_cart margin_r"><img src="<?php echo base_url();?>images/mypage_edit.png" /></a>
  <h1><?php echo $item;?></h1>
</div>
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="txt-confirmation"></div>
      <div class="favorite_main">
        <?php if(count($useraccounts) > 0){
							foreach($useraccounts as $key=>$val){
							?>
        <div class="cart-item-container shipment" id="<?php echo $val['id'];?>">
          <div class="cart-item-left"> <?php echo ucfirst($val['bank_name']);?> <br />
            <?php echo $val['bank_code'];?><br />
            <?php echo $val['bank_branch'];?><br />
            <?php echo $val['account_number'];?><br />
            <?php  if($val['account_type']==1){echo "Normal Account";}else{echo "other Account";}?>
          </div>
          <div class="cart-item-right"><a href="javascript:void(0);" onclick="delete_bank(<?php echo $val['id']?>);">
            <p id="delete<?php echo $val['id'];?>" >Delete</p>
            </a></div>
        </div>
        <?php }}?>
        <a href="<?php echo base_url();?>users/add_bank" class="information">
        <p> Add new Bank account </p>
        </a> </div>
    </div>
  </div>
</div>
<script type="text/javascript">
var BASEURL= '<?php echo base_url();?>';
function delete_bank(id)
{
	  if(confirm("Are you sure you want to delete bank account."))
	  {
		 $.ajax({
				url:BASEURL+'users/remove_bank/'+id,
				beforeSend:function()
				   {
					$("#delete"+id).html('<img src="<?php echo base_url();?>images/loader.gif" alt="proccessing"');
				   },
				  success:function(rep)
				  { 
				   if(rep=='success'){
					$("#"+id).slideUp("fast",function(){
						$("#"+id).remove();
					});
				   }
					else
					{
						$(".txt-confirmation").html('<font color="red">There is some technical error to remove this bank account . try later.</font>');
					}
				  }
		 });
	 }
}

</script>