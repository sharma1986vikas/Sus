<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1>Information</h1>
</div>

<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="favorite_main"> <a href="#" class="information">
        <p> <strong>10% off further time-limited sale, list price!</strong><br />
          Will be 10 percent off list price in August full summer price cut all at once, now! <br />
          2014/8/1 14:00 </p>
        </a> <a href="#" class="information">
        <p> <strong>Please check the amount of money assessment completed, the purchase</strong><br />
          Assessment amount will be &#165; 4,400. <br />
          2014/8/1 14:00 </p>
        </a>
        <div class="information bg_none">
          <p> <strong>10% off further time-limited sale, list price!</strong> </p>
        </div>
        <div class="information bg_none">
          <p> <strong>10% off further time-limited sale, list price!</strong> </p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php //$this->common->empty_field();?>