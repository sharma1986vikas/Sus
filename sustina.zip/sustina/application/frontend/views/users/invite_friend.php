<div class="header "> <a class="toggle_icon" href="<?php echo base_url();?>users/menu"> Menu</a>
  <h1 >Invite Friends</h1>
</div>

<!------------------main-------------------------->
<div class="container">
  <div class="main_container">
    <div class="middle-container">
      <div class="invite_main">
        <div class="invite_note">
          <p>If your friend enter your invitation code when he/she register to sustaina. <span>&#165;100 </span>coupon is presented to each of you and your friend. </p>
        </div>
        <div class="invite_code_box">
          <h1>Invitation Code <span><?php echo $this->session->userdata("user_uniq"); ?></span></h1>
        </div>
        <div class="friend_invited">
          <h1>Now<span><?php echo $this->user_model->get_total_friend();?></span>Friends</h1>
        </div>
        <div class="invite_range_main">
          <div class="invite_range">
            <div class="invite_range_image">
              <h2>5</h2>
            </div>
            <div class="invite_range_image pos1">
              <h2>15</h2>
            </div>
            <div class="invite_range_image pos2">
              <h2>30</h2>
            </div>
            <div class="invite_range_filled" style="width:<?php echo $this->user_model->get_total_friend()*3.33;?>%;"></div>
          </div>
          <p>Maximum &#165;5000 is presented when your friends register to sustaina using your invitaion code!</p>
        </div>
        <div class="invite_link_main"> <a class="invite_link" href="#">
          <h1>Invite<br />
            LINE</h1>
          </a>
          <?php
		//facebook message
$title = "test";//$this->config->item("sitename");
$image = base_url()."images.list_item.png";
//$link = ROOT_URL."/index.php?do=register&r=".$username;
$fb_link= base_url().$this->router->class."/".$this->router->method."/".$this->session->userdata("user_uniq");
//$message = $username. ' is using winning money off of sports at http://jockfox.com/demo. Click here to join and  Craig will get credit for recruiting you. Every game has a winner and that winner could be you. ';
//$message= $username. ' is using winning money off of sports at '.$site_name.' Click here to join';

		
	?>
          <?php $text="test";?>
          <?php $fb_text="testetsts";?>
          <?php  $new_link = base_url().$this->router->class."/".$this->router->method."/".$this->session->userdata("user_uniq");?>
          <a class="invite_link" title='Share with Facebook' href="http://www.facebook.com/sharer.php?s=100&p[title]=<?php echo $title; ?>&p[summary]=<?php echo $fb_text; ?>&p[images][0]=<?php echo $image; ?>&p[url]=<?php echo $fb_link; ?>" target="_blank">
          <h1>Invite <br />
            Facebook</h1>
          </a> <a  class="invite_link" target="_blank" title="Share with Twitter" href="http://twitter.com/share?url=<?php echo $new_link;?>&text=<?php echo $text;?>"  class="twitter-share-button"   data-lang="en" data-size="large" data-count="none" />
          <h1>Invite <br />
            Twitter</h1>
          </a> <a class="invite_link" href="#">
          <h1>Invite <br />
            E-mail</h1>
          </a> </div>
      </div>
      <div class="friend_invite_main">
        <?php 
	  
	  $friend = $this->products_model->get_all_friend();
	  foreach($friend as $k =>$v){
		//if($v["type"]=='fixed'){
			$clas='border_b';
		//}
		//else{
		//	$clas='';
		//}
	  ?>
        <div class="friend_invite_get <?php echo $clas;?>">
          <h1><?php echo $v["number"];?> friends Invite</h1>
          <span>
          <?php if($v["type"] == "percentage"){echo 'Buy '.$v["value"].'% OFF';}else{echo 'GET &#165; '.$v['value'].'';}?>
          </span></div>
        <?php }?>
      </div>
    </div>
  </div>
</div>