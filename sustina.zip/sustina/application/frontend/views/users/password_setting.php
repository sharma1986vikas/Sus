  <div class="header">
    <h1 class="margin_r"><?php echo $item;?></h1>
    </div>
    
    <div class="main_container">
    <div class="middle-container">
        <div class="txt-confirmation" style=" position:absolute; top: 38px;float:left; font-family: 'Open Sans', sans-serif;" id="message"> <font color='red'><?php echo $this->session->flashdata('errormsg'); ?></font> <font color='green'><?php echo $this->session->flashdata('successmsg'); ?></font> </div>

        <div class="email-textbox-container">
            <form method="post" action="<?php echo base_url();?>users/reset_password">
            <input type="hidden" name="id" value="<?php echo $userid;?>" />
            <input   class="email-textbox" type="password" value="" name="password"  />
            <button type="submit" class="email-signup_btn" name="facebook">set</button>
            </form>
        </div>
    </div>
    </div>