<div class="header">
  <div class="sub_container">
    <div class="left_logo"> <a href="<?php echo base_url();?>home"> <img src="<?php echo base_url();?>images/logo.png" height="72" width="276" alt="pic" /> </a></div>
    <div class="ryt_header">
      <ul class="menu">
        <li><a href="<?php echo base_url();?>pages/about_us"> About Us</a></li>
        <!--<li><a href="menu.html"> Menu  </a> </li>-->
        <li><a href="<?php echo base_url();?>partners"> Become A Partner </a> </li>
        <li><a href="<?php echo base_url();?>home/food_club"> FoodStop Club </a> </li>
        <li> <a href="<?php echo base_url();?>pages/blog">Blog</a> </li>
        <li><a href="<?php echo base_url();?>pages/contact"> Contact Us</a></li>
        <?php if($this->session->userdata("userid")!= ''){?>
       	 <li> <a href="<?php echo base_url();?>users/profile">Profile </a></li>
         <li> <a href="<?php echo base_url();?>users/log_out">Logout </a></li>
        <?php }else{?>
         <li> <a href="<?php echo base_url();?>users/">Login </a></li>
        <?php }?>
         </ul>
      <div class="clear"></div>
    </div>
    <div class="cart_head"> <img src="<?php echo base_url();?>images/cart.png" height="17" width="22" alt="pic" /> <span class="orr">( </span>0<span class="orr"> )</span>
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
</div>
