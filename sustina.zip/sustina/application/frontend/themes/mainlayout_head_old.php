<?php 
define("BASEURL",base_url());
?>
<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css" />
<link href="<?php echo base_url();?>css/responsive.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script>
var BASEURL = '<?php echo base_url();?>';
</script>