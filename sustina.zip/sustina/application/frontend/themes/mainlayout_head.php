<?php 
define("BASEURL",base_url());
?>
<link href="<?php echo base_url();?>css/jquery.bxslider.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo base_url();?>css/style.css" type="text/css" />
<link href="<?php echo base_url();?>css/responsive.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script>
var BASEURL = '<?php echo base_url();?>';
$(document).ready(function(){
$('.non_fav img').hover(function(){
	$(this).attr('src','<?php echo base_url()?>images/sbp-hrt-img2.jpg');
	},function(){
		 $(this).attr('src','<?php echo base_url()?>images/sbp-hrt-img.jpg'); 
	});
});
function add_favorite(id){
	
if(id !=""){
	if(confirm("Are you sure you want to add this product in your favorite list")){
		$.ajax({
			type : 'GET',
			url  : BASEURL+'users/add_favorite/'+id,
			data : '',
			success : function(rep){
				$("#fav_"+id).html('<a href="javascript:void(0);"><img src="<?php echo base_url();?>images/sbp-hrt-img2.jpg"></a>');
			}
		});
	  }
	}
}
</script>
