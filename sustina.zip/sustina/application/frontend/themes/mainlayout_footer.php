<div class="footer">
  <div class="sub_container">
    <ul class="menu_ftr">
      <li> <a href="<?php echo base_url();?>home/food_club">Foodstop club</a></li>
      <li> <a href="<?php echo base_url();?>partners/">Become a Partner </a></li>
      <li> <a href="<?php echo base_url();?>pages/about_us">About Us </a></li>
      <?php if($this->session->userdata("userid")== ''){?>
      <li> <a href="<?php echo base_url();?>users/sign_up">Register </a></li>
      <?php }?>
      <li> <a href="<?php echo base_url();?>pages/contact">Contact us </a></li>
      <li> <a href="<?php echo base_url();?>pages/blog">Blog </a> </li>
      <li> <a href="javascript:void(0)">Faq</a> </li>
    </ul>
    <div class="ftr_dec">
      <div class="ftr_dec"> &copy; Copyright Info <?php echo date('Y'); ?> </div>
    </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
</div>
