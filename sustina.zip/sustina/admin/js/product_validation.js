 /* <![CDATA[ */
 
 function product_validation(){
	 var title = $("#title").val().trim();
	 var category = $("#category").val().trim();
	 var subcategory = $("#subcategory").val().trim();
	 var short_description = $("#short_description").val().trim();
	 var long_description = $("#long_description").val().trim();
	 var brand = $("#brand").val().trim();
	 var price = $("#price").val().trim();
	 var condition = $("#condition").val().trim();
	 var meta_tag = $("#meta_tag").val().trim();
	 var color = $("#color").val().trim();
	 var size = $("#size").val().trim();
	 var quantity = $("#quantity").val().trim();
	 
	 var error='';
	 if(title == ""){
		 error = "Please enter title";
	 }
	 else if(category == ""){
		 error = "Please select category";
	 }
	  else if(subcategory == ""){
		 error = "Please select subcategory";
	 }
	 else if(category == ""){
		 error = "Please select category";
	 }
     else if(short_description == ""){
		 error = "Please enter short description";
	 }
	 else if(long_description == ""){
		 error = "Please enter long description";
	 }
	 else if(brand == ""){
		 error = "Please select brand";
	 }
	 else if(price == ""){
		 error = "Please enter price";
	 }
	 else if(isNaN(price)){
		 error = "Price should be numeric";
	 }
	 else if(condition == ""){
		 error = "Please select condition";
	 }
	 else if(meta_tag == ""){
		 error = "Please enter meta tags";
	 }
	 else if(color == ""){
		 error = "Please select color";
	 }
	 else if(size == ""){
		 error = "Please select size";
	 }
	 else if(quantity == ""){
		 error = "Please enter quantity";
	 }
	 else if(isNaN(quantity)){
		 error = "Quantity should be a numeric value";
	 }
	 else{
	 $(".color").each(function() {
		 //validate all colors
		var att_val = $(this).val();
		   if (att_val=="") {
			    error ="Please select all color";
				return false;
		  }
		  //validate all sizes
		   $(".size").each(function() {
			var att_val = $(this).val();
			   if (att_val=="") {
					error ="Please select all size";
					return false;
			  }
			  //validate all quantity
			   $(".quantity").each(function() {
				var att_val = $(this).val();
				   if (att_val=="" || isNaN(att_val)) {
						error ="Please enter  all quanties and it should be in numeric";
						return false;
				  }
			   });
		   });
	   });
	 }
	 if(error != '' && error != null){	
		$('#error').html(error).css({'color':'red','font-weight':'bold'});
		$('#error').show("normal");
		window.scrollTo(0,0);
		setTimeout(function() {
		$('#error').fadeOut('slow');
		}, 3000);
		return false;
	}
	else{
		return true;
	}
 }
   jQuery(function(){
   /* jQuery("#title").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please enter title"
     });
	  jQuery("#category").validate({
		expression: "if (VAL > 0) return true; else return false;",
		message: "Please select category"
     });
	 jQuery("#subcategory").validate({
		expression: "if (VAL > 0) return true; else return false;",
		message: "Please select sub-category",
     });
	  jQuery("#short_description").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please enter short description"
     });
	  jQuery("#long_description").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please enter long description"
     });
	  jQuery("#brand").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please select brand"
     });
	  jQuery("#price").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please enter price"
     });
	  jQuery("#price").validate({
		  expression: "if (!isNaN(VAL)) return true; else return false;",
		//expression: "if (VAL.match(/^[0-9]*$/) && VAL) return true; else return false;",
        message: "Please enter a valid integer"
     });
	  jQuery("#condition").validate({
		expression: "if (VAL > 0) return true; else return false;",
		message: "Please select condition"
     });
	  jQuery("#meta_tag").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please enter meta tags e.g. shirt,t-shirt,car"
     });
	 
	  jQuery("#color").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please select color"
	 });
	  jQuery("#size").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please select size"
     });
	  jQuery("#quantity").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please select quantity"
     });
	 
	 jQuery("#quantity").validate({
		expression: "if (!isNaN(VAL)) return true; else return false;",
		message: "Please select quantity"
     });
	jQuery("#color1").validate({
		expression: "if (VAL) return true; else return false;",
		message: "Please select color"
     });*/
	 
	/*jQuery("#price").validate({
	   	expression: "if (VAL.match(/^[0-9]*$/) && VAL) return true; else return false;",
		message: "Please enter a valid integer"
	});
	jQuery("#select").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please select dish"
                });
    jQuery("#password").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter password"
                });jQuery("#password").validate({
                    expression: "if (VAL.length > 5 && VAL) return true; else return false;",
                    message: "Please enter a valid Password"
    });
	jQuery("#password").validate({
                    expression: "if (VAL.length > 5 && VAL) return true; else return false;",
                    message: "Please enter a valid Password" 
                });jQuery("#verify_password").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter verify password"
                }); jQuery("#verify_password").validate({
                    expression: "if ((VAL == jQuery('#password').val()) && VAL) return true; else return false;",
                    message: "Verify password field doesn't match the password field"
                });  jQuery("#email").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter email"
                }); jQuery("#email").validate({
                    expression: "if (VAL.match(/^[^\\W][a-zA-Z0-9\\_\\-\\.]+([a-zA-Z0-9\\_\\-\\.]+)*\\@[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_]+)*\\.[a-zA-Z]{2,4}$/)) return true; else return false;",
                    message: "Please enter a valid Email ID"
                });jQuery("#contact").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter contactno"
                }); jQuery("#contact").validate({
                    expression: "if (VAL.match(/^[0-9]*$/) && VAL) return true; else return false;",
                    message: "Please enter a valid integer"
                });jQuery("#contact").validate({
                    expression: "if (VAL.length==10  && VAL) return true; else return false;",
                    message: "Please enter a valid 10 digit number" 
                });jQuery("#age").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please enter age"
                });jQuery("#age").validate({
                    expression: "if (VAL.match(/^[0-9]*$/) && VAL) return true; else return false;",
                    message: "Please enter a valid integer"
                });jQuery("#gender").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please select gender"
                });jQuery("#location").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Please select location"
                });*/
            });
			     /* ]]> */  
	


$(document).ready(function(e) {
	var category =  $("#category").val();
	var subcategory =  $("#subcategory").val();
    get_subcategory(category,subcategory);
	//debugger;
});
function remove_class(){
	$("#subcategory").removeClass("ErrorField"); 
}
function get_subcategory(category,subcategory){
	var subcategory = $("#subcategory").val();
	$.ajax({
		type:'GET',
		beforeSend : function (){
        	$("#city_img").show();        
        },
		url:BASEURL+'products/get_subcategory/'+category+"/"+subcategory,
		data:'',
		success:function(result)
		{
			$("#subcat_data").html(result);
			$("#city_img").hide();
		}	
	});	
}
//delete clone
/*function remove_data(id){
	$("#del_"+id).slideUp("fast",function(){
  		 $("#del_"+id).remove();
  });
}
var counterUpload = 1;
 var limit = 20;
	 function addUpload(){
	
	 if (counterUpload == limit)  {
		  alert("You have reached the limit of adding " + counterUpload + " inputs");
	 }
	 else {
		  var newdiv = document.createElement('div');
		   newdiv.innerHTML = '<div class="mukesh_outer_container" id="del_' + counterUpload + '" >\n\
			  <div class="mukesh_outer_div1">\n\
				  <div class="mukesh_left_div">Color</div>\n\
				  <div class="mukesh_right_div">\n\
				  <select class="color" name="color[' + counterUpload + ']" id="color' + counterUpload + '" style="width:255px; height:35px;"  />\n\
				  <option value="">-Select color-</option></select>\n\
				  <span class="txt_clone"> <a href="javascript:void(0);" onclick="remove_data(' + counterUpload + ');">\n\
				  <img src="'+BASEURL+'/images/delete.png" title="Remove variation" /></a></span>\n\
				  <div class="clear"></div></div>\n\
				  <div class="clear"></div>\n\
				  <div class="mukesh_left_div">Size</div>\n\
				  <div class="mukesh_right_div">\n\
				  <select  class="size"  name="size[' + counterUpload + ']" id="size' + counterUpload + '" style="width:255px; height:35px;"/>\n\
				  <option value="">-Select size-</option></select><div class="clear"></div></div>\n\
				  <div class="clear"></div>\n\
				  <div class="mukesh_left_div">Quantity</div>\n\
				  <div class="mukesh_right_div">\n\
				 <select  class="quantity"   name="quantity[' + counterUpload + ']" id="quantity' + counterUpload + '" style="width:255px; height:35px;"/>\n\
				 <option value="">-Select quantity-</option></select><div class="clear"></div></div>\n\
				  <div class="clear"></div>\n\
			   </div>\n\
			  <div class="clear"></div>\n\
		  </div> <div class="clear"></div><span id="msg"></span>';
		  document.getElementById("dynamicInputUpload").appendChild(newdiv);
		  counterUpload++;
	 }
 } 
*/