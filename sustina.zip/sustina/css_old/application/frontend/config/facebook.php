<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appID']	= '498474556892510';


$config['appSecret']	= '7ca21bcadb0c4b711b3b7b01f9f14410';


/* End of file facebook.php */
/* Location: ./application/config/facebook.php */
