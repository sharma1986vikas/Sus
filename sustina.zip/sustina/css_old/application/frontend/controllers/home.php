<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class home extends CI_Controller {

	public function __construct(){
		
		parent::__construct();
		//$this->load->model("page_model");
		$this->load->model('user_model');
		$this->load->model('email_model');
		$this->load->model('products_model');
	}
	////////////////site landing page //////////////////	
	public function index(){
	    $data["item"]="Sustaina";
		$data["link"] = 'active';
		$data["master_title"]=$this->config->item("sitename")."- Home";  
		$data["master_body"]="home";
		$this->load->theme('mainlayout',$data);
	}
	public function video(){
	    $data["item"]="Sustaina";
		$data["link"] = 'active';
		$data["master_title"]=$this->config->item("sitename")."- Home";  
		$data["master_body"]="video";
		$this->load->theme('mainlayout',$data);
	}
	/*********site signup page**************************/
	public function signup(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Sign up";
			$data["link"] = 'active';
			$data["master_title"]=$this->config->item("sitename")."- signup";  
			$data["master_body"]="signup";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	
	public function signup_site(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Signup- Email";
			$data["link"] = 'active';
			$data["signup_site"] = $this->session->flashdata("tempdata");
			$data["master_title"]=$this->config->item("sitename")." - signup";  
			$data["master_body"]="signup_site";
			$this->load->theme('mainlayout',$data);
			}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	public function signup_site_complete(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Signup";
			$data["link"] = 'active';
			$data["master_title"]=$this->config->item("sitename")." - signup";  
			$data["master_body"]="signup_site_complete";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	public function signup_email_confirmation(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Email Confirmation";
			$data["link"] = 'active';
			$data["master_title"]=$this->config->item("sitename")." - Email Confirmation";  
			$data["master_body"]="signup_email_confirmation";
			$this->load->theme('mainlayout',$data);
			}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	public function signin(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Login";
			$data["link"] = 'active';
			$data["master_title"]=$this->config->item("sitename")." - login";  
			$data["master_body"]="signin";
			$this->load->theme('mainlayout',$data);
			}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	//after sighnup user click on link and comes here 
	public function email_signin(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Email Login";
			$data["link"] = 'active';
			$data["email_signin"] = $this->session->userdata("tempdata");
			$data["master_title"]=$this->config->item("sitename")." - Email Login";  
			$data["master_body"]="email_signin";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	public function signin_site(){
		$user = $this->session->userdata("userid");
		if(empty($user)){
			$data["item"]="Email Login";
			$data["link"] = 'active';
			$data["signin"] = $this->session->userdata("tempdata");
			$data["master_title"]=$this->config->item("sitename")." - Email Login";  
			$data["master_body"]="signin_site";
			$this->load->theme('mainlayout',$data);
		}
		else{
			redirect(base_url()."users/my_page");
		}
	}
	
	
	//request a cloth
    public function sell_cloth(){
		$this->common->is_logged_in();
	    $data["item"]="Sell cloths";
		$data["master_title"] = $this->config->item("sitename")." - Sell cloths"; 
		$data["selldata"] = $this->session->flashdata("tempdata"); 
		$data["master_body"]="sell_cloth";
		$this->load->theme('mainlayout',$data);
	}
	//request a cloth
    public function sell_cloth_success(){
		$this->common->is_logged_in();
	    $data["item"]="Sell cloths";
		$data["master_title"] = $this->config->item("sitename")." - Sell cloths"; 
		$data["selldata"] = $this->session->flashdata("tempdata"); 
		$data["master_body"]="sell_cloth_success";
		$this->load->theme('mainlayout',$data);
	}
	public function add_referal_code(){
		$arr["referal_code"] = $this->input->post("referal_code");
		$this->session->set_flashdata("tempdata",$arr);	
		
		if($this->validations->validate_add_referal_code($arr)){
			if($arr["referal_code"] <> ""){
				$this->session->set_userdata("tempdata",$arr);
				redirect(base_url().$this->router->class."/signup");	
			}
			else{
				redirect(base_url()."home/signup");	
			}
		}	
		else{
			$this->session->set_flashdata("errormsg","No such referal code exists, wrong information");
			$err=1;
			redirect(base_url().$this->router->class."/home");
		}
		
	}
	
	public function add_sell_cloth_to_database()
	{
		
	    $arr["id"] = trim($this->input->post("id"));
		$arr["category_id"] = $this->input->post("category_id");
		$arr["brand_id"] = $this->input->post("brand_id");
		$arr["price_from"] = $this->input->post("price_from");
		$arr["price_to"] = $this->input->post("price_to");
		$arr["cond1"] = $this->input->post("cond1");
		$arr["cond2"] = $this->input->post("cond2");
		$arr["cond3"] = $this->input->post("cond3");
		$arr["terms"] = $this->input->post("terms");
		$arr["userid"] = $this->session->userdata("userid");
		$arr["status"] = 0;
		$arr["created_on"] = time();
		$arr["requested_time"] =time();
		
		$this->session->set_flashdata("tempdata",$arr);	
		unset($arr["category_id"]);
		unset($arr["brand_id"]);
		unset($arr["price_from"]);
		unset($arr["price_to"]);
			if($this->validations->validate_sell_cloth($arr)){
				unset($arr["terms"]);
				if($this->products_model->add_edit_sell_cloth($arr)){
					redirect(base_url().$this->router->class."/sell_cloth_success");
				}	
				else
				{
					$this->session->set_flashdata("errormsg","There was error in adding this request.");
					$err=1;
				}
				redirect(base_url().$this->router->class."/sell_cloth");
				}	
			else{
				$err=1;
				redirect(base_url().$this->router->class."/sell_cloth");
			}
	}
	
	public function get_price_by_category()
	{
		$cid = $this->uri->segment(3);
		$bid = $this->uri->segment(4);
		$price = '';
		$price = $this->products_model->get_price_by_category_brand($cid,$bid);
		echo $price;die;
	}
	
	
	public function add_user_to_database()
	{
		
	    $arr["id"] = trim($this->input->post("id"));
		$arr["email"] = trim(mysql_real_escape_string($this->input->post("email")));
		$arr["password"] = trim(mysql_real_escape_string($this->input->post("password")));
		$arr["referal_code"] = $this->input->post("referal_code");
		$arr["user_type"] = "buyer";
		$arr["user_status"] = 0;
		$arr["created_on"] = time();
		$arr["user_uniq"] = $this->common->user_uniq("users","user_uniq",6);
		$this->session->set_flashdata("tempdata",$arr);	
		
			if($this->validations->validate_user_data($arr)){
				//print_r($arr);
				if($this->user_model->add_edit_user($arr)){
					$last_id = $this->db->insert_id();
					$emailarr["to"] = $arr["email"];
					$emailarr["subject"] = "Sign Up Verification Notification";
					$emailarr["message"] = "<p>Helo user </p>
					<p>Welcome to ".$this->config->item("sitename")."</p> 
					<p>We are glad you signed up for your user account. Once you confirm your email address through the link below, you are all set to build your profile.</p>
					<p>Please click on the link below to be redirected to your recently created ".$this->config->item("sitename")." profile.</p>
					<p>".base_url()."home/verify_email/?verify=".base64_encode($last_id)."</p>
					<p>If you do have any further questions, concerns, or suggestions, shout out to our team anytime through the contact form on</p> 
					<p>".base_url()."pages/contact</p>
					<p>We hope you have an enjoyable experience with us.</p>
					<p>Best Wishes,</p>
					<p>The ".$this->config->item("sitename")." Team</p>";
					$this->email_model->sendIndividualEmail($emailarr); 
					$err=0;
					redirect(base_url().$this->router->class."/signup_email_confirmation");
					//$this->session->set_flashdata("successmsg","Your account was successfully created. Please check your inbox for a confirmation email.");
					
				}	
				else
				{
					$this->session->set_flashdata("errormsg","There was error in adding this user.");
					$err=1;
				}
				redirect(base_url().$this->router->class."/signup_site");
				}	
			else{
				$err=1;
				redirect(base_url().$this->router->class."/signup_site");
			}
	}
	
 public function verify_email()
	{
		 $user_id = base64_decode($this->input->get("verify"));//$loginId;
		 $verify = $this->user_model->verify_email($user_id);
	   
		 if($verify == 0)
		 {
			$this->session->set_flashdata("successmsg","Your email has been successfully verified");
		}
		else{
			$this->session->set_flashdata("successmsg","Your email has been already  verified please login!");
		}
		redirect(base_url()."home/email_signin");
	}
	
	//check login details and login the user
	public function logins_check_user_login()
	{
		$login["email"] = trim(mysql_real_escape_string($this->input->post("email")));	
		$login["password"] = trim(mysql_real_escape_string($this->input->post("password")));
		$data["signin"] = $this->session->set_userdata("tempdata",$login);
				
		if($this->common->authenticateUserLogin($login))
		{
			if($this->session->userdata('user_type') == 'buyer'){
					redirect(base_url()."products/brand_purchase");
			}
			else{
				redirect(base_url()."home/signin_site");
			}
		}
		else
		{	
			redirect(base_url()."home/signin_site");
		}
	}
	
	
	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url()."home/");	
	}
	public function downloadpdf(){
		$file="test.pdf";
		if (file_exists($file)) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header("Content-Type: application/force-download");
			header('Content-Disposition: attachment; filename=' . urlencode(basename($file)));
			// header('Content-Transfer-Encoding: binary');
			header('Expires: 0');
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			ob_clean();
			flush();
			readfile($file);
			exit;
		}
	}
}
